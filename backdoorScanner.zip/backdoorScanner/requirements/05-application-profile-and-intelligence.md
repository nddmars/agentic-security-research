# 05 Application Profile and Intelligence Layer

Author: Surya

## Application profile

We have no up-front visibility into the architecture of thousands of applications, so the scanner builds and maintains an **application profile** on our side.

### Profile contents

- Application identifier and source reference (repository, archive, scan or release ID).
- Languages and approximate size per language.
- Frameworks and versions detected (web, ORM, templating, front end, messaging, scheduling).
- Build system and package managers.
- Entry-point inventory: routes, endpoints, jobs, listeners, CLI commands, startup hooks.
- Menu and navigation sources: where menus and routes are defined.
- Authentication and authorization mechanism and where role checks live.
- Dangerous-capability inventory: where file, process, network, database and email capabilities are used.
- Configuration and extension points (plugins, scripts, templates, dynamic loading).
- Third-party library inventory (feeds phase 2).
- Profile version and the scan that produced it, so changes between releases are visible.

### Use of the profile

- Select the right framework adapters and rules for the application.
- Support menu, URL and role discovery.
- Drive baseline and diff scans.
- Give the triage agent context about what the application is supposed to do.

## Two-layer scanning

### Layer 1: deterministic analysis (exhaustive, repeatable)

- Parse source to ASTs, build call graphs where possible, run text and config search (ripgrep and similar), apply rules and queries across every file.
- Output: complete candidate POIs with precision tags (for example full analysis, name-based, text-match-only).
- This layer must not skip files silently; unparsed files are reported.

### Layer 2: intelligence layer (enrichment and discovery)

The model works only on what Layer 1 built: cited snippets, call-graph facts and the profile. It does the work rules are bad at:

- Build the application profile in unfamiliar stacks.
- Work out where menus, routes and role checks live in unknown frameworks.
- Link a function to its URL, menu path and roles.
- Judge whether a candidate looks like business functionality or an unexplained utility.
- Spot obfuscation, odd logic and unusual structure that no rule anticipated, as a second pass over code Layer 1 marked unusual (for example high-entropy strings, dynamic loading, unexplained network use).
- Normalize and group related candidates, for example several fragments of one backdoor.

### Guardrails

1. The model may **add or enrich** POIs; it may **never remove or downgrade away** a POI that Layer 1 found.
2. Every model claim cites snippets by ID; claims without citations are discarded.
3. Scanned code and comments are treated as data, never as instructions; prompt-injection defenses apply.
4. Secrets are masked before any code reaches a model.
5. Model output is validated against a schema; invalid output is rejected and logged.
6. The model gives only a coarse priority hint. Final verdict and ranking belong to triage or a human reviewer.
7. Each model-added POI is marked with its origin so its reliability can be measured separately.

## Degradation

If the call graph or parsing is unavailable for a language or repository, the scanner falls back to name-based and text-based detection, tags every POI with the reduced precision, and never reports "clean" for an area it could not analyze.
