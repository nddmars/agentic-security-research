# 01 Scope and Goals

Author: Surya

## Goal

Find suspicious or malicious code in application source and record each finding as a Point of Interest (POI) with enough evidence that a reviewer or the triage agent can judge intent.

## Core idea

Functionality that is not documented as a business requirement is suspicious. We do not have the business requirements for most applications, so we infer "is this business functionality?" from the code itself: is it reachable from the user-facing menu, from a URL, from a scheduled job, or is it a hidden utility or an entry point nobody links to.

## In scope

- Source code of internal applications: thousands of applications, mostly Java, Python, Node.js, Go and .NET. Mobile (Swift, Kotlin and others) is rare and comes later.
- Detection of suspicious functionality, malicious techniques, and concealment.
- Application profiling (languages, frameworks, entry points, extensions) maintained on our side.
- Menu, URL and role reachability for every POI.
- Baseline and diff scanning across releases.
- Supply-chain POIs (build scripts, dependency sources).
- Phase 2: unknown library detection and handoff to a separate analysis service.

## Out of scope

- Finding exploitable vulnerabilities (that is Checkmarx and the triage agent).
- Final verdicts on whether a POI is malicious (that is triage or a human reviewer).
- Running or executing the scanned code, ever.
- Analyzing library internals (separate service, phase 2).
- Runtime or dynamic analysis.

## Scale

Enterprise scale: thousands of applications, many frameworks, repositories from tiny to very large. The scanner must be parallelizable, resumable, and cheap enough to run on every release.

## Principles

1. **Minimize false negatives.** Over-reporting a POI is acceptable; missing one is not. Review noise is managed by priority hints, allowlists and diffing, never by silently dropping candidates.
2. **Deterministic first, intelligence second.** Exhaustive analysis (AST, ripgrep, call graphs, rules) is deterministic and repeatable. The model layer only enriches what the deterministic layer built.
3. **The model may add or enrich POIs, never remove one that rules found.**
4. **Evidence over opinion.** Every POI cites code snippets with file and line.
5. **Scanned code is hostile data.** Never executed; never treated as instructions to a model.
6. **Independent.** No runtime dependency on Checkmarx or the triage agent.
7. **Coarse priority hint only.** The scanner suggests priority; triage owns final ranking.
