# 02 POI Catalog

Author: Surya

Every category below must be detected. The catalog is extensible: new categories and techniques can be added without changing the output schema.

## A. Dangerous capability (functionality that should rarely or never exist)

- **File upload** endpoints or handlers.
- **File download** endpoints, especially with caller-controlled paths.
- **Command execution**: running shell commands, scripts or binaries, including process builders, runtime exec, subprocess, child_process, os/exec, Process.Start.
- **Command injection surfaces**: command strings built from variable input.
- **Free-form database query**: any function that lets a caller supply arbitrary SQL or query text and run select, update or delete. No legitimate business application exposes a free-form query; treat every instance as suspicious.
- **Script invocation**: calling shell scripts, PowerShell, batch files, or other interpreters as part of application functionality.
- **Dynamic code execution**: eval, exec, script engines, expression evaluators, dynamic compilation, runtime class loading, reflection used to invoke named methods.

## B. Data exfiltration and leakage

- **Outbound network connections** to hardcoded, unusual or configurable external hosts (sockets, HTTP clients, raw TCP or UDP).
- **Outbound email** (SMTP clients, mail APIs) not tied to a documented notification feature.
- **Exfiltration over DNS**: lookups where data is encoded into hostnames or TXT queries.
- **Exfiltration over HTTP**: posting data to external endpoints, webhooks, paste or file-sharing services, cloud storage URLs.
- **Dumping data to files or shared drives**: writes to network shares, UNC paths, mounted shared volumes, cloud buckets, temp locations outside the application's normal data directories.
- **Sensitive data to logs or shared drives**: credentials, tokens, credit card numbers, SSNs and similar identifiers written to logs, files or shared locations.
- **Bulk data export**: code that reads large result sets or whole tables and serializes them out.

## C. Information gathering

- Enumeration of environment variables, system properties, hostnames, network interfaces, users, processes, installed software, files and directories.
- Reading credential stores, key files, configuration secrets, browser or OS credential locations.
- Collecting data about other tenants, users or sessions beyond what the feature needs.

## D. Concealment and obfuscation

- Obfuscated or encoded payloads: base64, hex or encrypted blobs that are decoded then executed or loaded.
- String assembly to hide sensitive names or URLs (concatenation, reversed or XOR strings).
- Reflection and dynamic loading to avoid static visibility.
- Disabled, bypassed or tampered logging and audit calls.
- Code in unusual places: build scripts, test directories, vendored or generated code, resource files, comments carrying payloads.

## E. Hidden access and backdoors

- Undocumented or unlinked endpoints.
- Hardcoded accounts, passwords, API keys, tokens.
- Magic values: special headers, parameters, usernames or IP addresses that change behavior or skip authentication or authorization.
- Authentication or authorization bypass for specific users, roles, hosts or networks.
- Role-restricted hidden functions (reachable only by one or few roles).

## F. Time bombs and conditional triggers

Covered in detail in file 04.

## G. Supply-chain POIs

- Install, build and CI scripts that run commands or download and run code.
- Dependencies from unusual registries, raw URLs, git references or local paths.
- Typosquatted or look-alike package names.
- Code fetched and executed at runtime.
- Modified or vendored copies of well-known libraries.

## H. Sensitive-data handling anomalies

- Credentials, card numbers, SSNs, personal data in logs, error messages, files, or outbound calls.
- Weak or missing masking where sensitive fields are serialized.

## Category metadata

Each category has: an ID, name, description, default priority hint, languages where detection applies, and the techniques that detect it (rule, AST query, call-graph query, intelligence-assisted).
