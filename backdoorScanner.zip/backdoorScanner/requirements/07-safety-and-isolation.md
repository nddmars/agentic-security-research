# 07 Safety and Isolation

Author: Surya

The scanner reads code that may be deliberately hostile. The scanner itself must not become the attack path.

## Hard rules

1. **Never execute scanned code.** No building, running, installing dependencies, running tests, or evaluating scripts from the scanned source. Analysis is static only.
2. **Scanned content is data, never instructions.** Comments, strings, file names, README files and configuration may contain prompt-injection attempts aimed at the model layer. They are never followed.
3. **Mask secrets before model use.** Credentials, tokens, keys, card numbers, SSNs and similar values are redacted before any snippet is sent to a model or stored in a report.
4. **No outbound access from the analysis environment** except to approved endpoints (artifact source, model gateway, results store).

## Source handling

- Fetch source only from approved internal locations; validate URLs to prevent server-side request forgery.
- Extract archives safely: protect against path traversal, symlinks, zip bombs, excessive file counts and nested archives, with size and time limits.
- Do not follow symlinks outside the extraction directory.
- Treat very large repositories (up to many gigabytes) with streaming, limits and clear partial-coverage reporting.
- Delete extracted source after the scan, keeping only evidence snippets needed for the report.

## Isolation

- Each scan runs in an isolated, ephemeral environment (pod or container) with no access to other applications' source or results.
- Run as non-root with a read-only root filesystem where possible, restricted resources, and no privileged capabilities.
- Network policy denies everything not explicitly required.
- Parsers and analyzers run with time, memory and CPU limits, since malformed or adversarial files can crash or hang them. A failure on one file is recorded and the scan continues.

## Model-layer protections

- Structured output only, validated against a schema.
- Every claim must cite snippet IDs.
- The model has no tools that can execute code, write outside the results store, or reach the network.
- Different model or second-pass comparison for high-priority POIs may be used to reduce single-model error.
- Prompts keep instructions and untrusted content in clearly separated sections.

## Data protection

- Reports can contain sensitive code excerpts: restrict access, encrypt at rest and in transit, and define retention.
- Never log full source or unmasked secrets.
- If the scanner discovers live secrets, they are reported by location and type, not by value.

## Audit

- Record who ran or viewed each scan and report, which models and rule versions were used, and any allowlist changes.
- Rule and prompt changes are versioned and reviewed, because they decide what the scanner can see.

## Integrity of the scanner itself

- Detection rules and framework adapters are code-reviewed, versioned and tested against the evaluation corpus (file 08) before release.
- A rule change that lowers the measured detection rate is blocked.
