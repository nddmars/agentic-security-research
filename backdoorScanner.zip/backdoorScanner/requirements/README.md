# POI Scanner: Requirements Pack

Author: Surya
Status: Requirements v1 (copied from Drive on 2026-11-12). Design is in `../design/`. Open questions are tracked in `../design/13-rollout-and-decisions.md`.
Date: 2026-11-02

## What this project is

A standalone scanner agent that reads application source code and produces **Points of Interest (POIs)**: places in the code that look suspicious or potentially malicious and need deeper review. It is **not** a vulnerability scanner. It looks for hidden or unexplained functionality and for malicious techniques, not for exploitable bugs.

## Why a new tool

Checkmarx (CxSAST) is built for vulnerabilities and is weak at pattern-based search for suspicious or malicious behavior. The existing triage design (cxtriage) handles Checkmarx vulnerability findings and stays a separate project. This scanner is independent of it. At some point the triage agent may be invoked on POIs produced by this scanner, so the POI output must be usable as triage input.

## Relationship to other projects

- **Scanner (this project):** finds and records POIs. Independent. Does not depend on Checkmarx or on the triage agent.
- **Triage agent (separate):** gives the deep verdict on a POI. May be invoked later. The scanner never makes final verdicts.
- **Library analysis service (separate, phase 2):** analyzes unknown libraries. The scanner only calls it through a defined interface.
- **Similarity service (separate service, part of this project):** reports which components share code.

## Files in this pack

1. README.md: this index.
2. 01-scope-and-goals.md: goals, non-goals, scale, principles.
3. 02-poi-catalog.md: every category of POI the scanner must detect.
4. 03-functionality-and-reachability.md: business-functionality check, menu and URL discovery, role capture.
5. 04-time-bomb-and-trigger-detection.md: time bombs and conditional triggers.
6. 05-application-profile-and-intelligence.md: application profiling and the intelligence layer.
7. 06-output-and-evidence.md: POI record fields, allowlist, baseline and diff.
8. 07-safety-and-isolation.md: handling hostile code safely.
9. 08-evaluation-and-test-corpus.md: how we measure misses.
10. 09-phase2-unknown-libraries.md: unknown library detection and the separate analysis service.
11. 10-open-questions.md: items still to decide before design.

## Reading order

Start with 01 and 02, then 03 to 06 for behavior, then 07 to 09 for safety, quality and phase 2.
