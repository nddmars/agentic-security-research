# 04 Time Bomb and Trigger Detection

Author: Surya

## Goal

Find code that stays dormant until a condition is met, then does something harmful or unexplained. These must be reviewed even when the triggered action looks harmless in isolation.

## Trigger families

### 1. Date and time triggers

The scanner must recognize many techniques, not just one API. Examples across languages:

- Comparisons against the current date or time: system clock, calendar and date-time classes, epoch timestamps, monotonic or uptime counters.
- Comparison against **hardcoded dates or times**: literal dates, epoch constants, year, month, day or weekday checks, "after date X" or "before date X" logic.
- Day-of-week, hour-of-day, month-end, quarter-end, holiday and weekend conditions.
- Elapsed-time triggers: time since install, first run, deployment, build, last login, file modification time, or license start.
- Scheduled execution: cron expressions, schedulers, timers, delayed tasks, sleep-then-act patterns, quartz and similar frameworks, OS scheduled tasks created from code.
- Time obtained indirectly: from a remote server, an HTTP header, a database timestamp, a file timestamp, or an NTP query, which can be used to evade local clock checks.
- Time arithmetic that hides the target date: computed or obfuscated constants, string-assembled dates, offsets from build time.
- Counters and usage thresholds: execute after N runs, N logins or N records.

### 2. Account and identity triggers

- Condition on a specific user existing or not existing (for example "if this account is deleted or disabled, act").
- Conditions on a specific username, employee ID, email, domain or role.
- Triggers tied to a specific customer, tenant or record.
- Triggers based on the absence of an expected entity (a missing heartbeat, a missing file, a missing user).

### 3. Environment and host triggers

- Hostname, IP address, domain, network range, region, locale or time zone checks.
- Environment variable, system property, or configuration flag checks.
- Presence or absence of files, registry keys, processes, debuggers, sandboxes or monitoring agents.
- Production versus test environment detection used to behave differently.

### 4. External signal triggers

- Behavior controlled by a remote file, DNS record, web page, message or database value (kill switch or remote enable).
- Behavior triggered by a special input: magic header, parameter, file name or payload.

### 5. Logic-bomb structure

- Rarely executed branches that perform destructive, exfiltrating or privilege-changing actions.
- Conditions whose true branch performs deletion, data modification, credential changes, disabling of controls or network calls.

## Required record fields for a trigger POI

- trigger_family and technique (from the lists above)
- the condition as written, with cited snippet
- the guarded action and its category from the POI catalog
- whether the trigger value is hardcoded, computed or external
- reachability facts from file 03

## Detection approach

- Deterministic: AST queries and search for date and time APIs, literal date patterns, user and host checks, and scheduler constructs, then data-flow from the condition to the guarded action.
- Intelligence-assisted: for computed or obfuscated conditions and for conditions that rules cannot classify, the model proposes a classification over cited snippets. It may add POIs but never remove rule-found ones.
- Every trigger POI is recorded even when the benign explanation looks likely; triage decides.
