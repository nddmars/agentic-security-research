# 03 Functionality and Reachability

Author: Surya

## Why this matters

We usually have no business requirements for an application, so we cannot check code against a spec. Instead, the scanner answers: **is this functionality exposed to normal users through the application's own navigation?** Functionality that is reachable from the user-facing menu is more likely to be intended business functionality. Functionality that is hidden, role-restricted, or only a utility is flagged for review.

## Required output for every POI

At the end of a scan, each POI must carry these reachability facts:

1. **navigation_url**: the URL or route used to reach the functionality. This is required regardless of whether the functionality is reachable from a menu. If no URL exists (a scheduled job, a message consumer, a library function), the record says so explicitly and gives the actual entry type instead.
2. **menu_accessible**: yes, no or unknown. Yes means a menu, navigation item, link or button in the front end leads to it.
3. **menu_path**: the menu entries leading to it, when menu_accessible is yes.
4. **roles_required**: the roles, permissions or groups needed to reach it, when determinable. Unknown is allowed, but must be recorded as unknown.
5. **entry_type**: web route, API endpoint, scheduled job, message listener, CLI command, startup hook, library-internal, or unreachable.
6. **reachability_evidence**: cited snippets for the route definition, the menu definition, and the role check.

## Classification of exposure

- **Menu-exposed, all roles:** most likely business functionality. Still recorded and lower priority hint.
- **Menu-exposed, restricted roles:** recorded with roles. Role-restricted access to a dangerous capability is itself a flag.
- **Not menu-exposed, has URL:** hidden endpoint. Flagged. Intent must be reviewed.
- **Menu-exposed but described as a utility:** still flagged. A menu entry does not make dangerous functionality acceptable.
- **No entry point found:** dead code or dormant code. Flagged for review since dormant code can be a latent backdoor.

## Menu and URL discovery

Menus and routes can live in code, in configuration, in templates, in client-side bundles or in a database, and the frameworks are not known in advance. Discovery is therefore framework-adaptive:

- Framework adapters for Java (for example Spring MVC and JAX-RS, servlets, Struts), Python (Django, Flask, FastAPI), Node.js (Express, Nest, Next and similar), Go (net/http, gin, echo, chi), and .NET (ASP.NET MVC, Razor Pages, Web API, Blazor).
- A generic fallback that uses search and intelligence to find route tables, annotations, URL maps, menu definitions and navigation components in unfamiliar frameworks.
- Front-end analysis for menus defined in templates or JavaScript (menu config files, navigation components, route guards).
- Where the menu is database-driven, the scanner records menu_accessible as unknown and notes the seed data or table it depends on.

## Call-chain linking

A POI is often deep inside a helper. The scanner links the POI back to entry points through the call graph so that the route, menu entry and role check can be attached. When the link is name-based or incomplete, the record carries a precision marker so reviewers know how reliable the link is.

## Role capture

Record role checks found on the path from entry point to POI: annotations, middleware, filters, guards, inline checks and configuration-based rules. A dangerous function reachable only by one rare role, or by a hardcoded user, is surfaced specifically.
