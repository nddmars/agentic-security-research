# 06 Output and Evidence

Author: Surya

## POI record (required fields)

Each Point of Interest is one record. The record must be directly usable as input to the triage agent.

- **poi_id**: stable ID. The same code location and technique produces the same ID across scans so diffs and allowlists work.
- **scan_id, application_id, profile_version**
- **category** and **technique** (from the POI catalog, file 02; trigger families from file 04)
- **title** and short description of what the code does, in neutral language.
- **location**: file path, start and end line, function or method name, language.
- **evidence**: one or more cited snippets, each with a snippet ID, file and line range, and the exact text (secrets masked).
- **origin**: rule, AST query, call-graph query, text search, or intelligence layer. Model-added POIs are marked.
- **confidence** and **precision tag**: how the POI was found and how reliable the supporting facts are (full analysis, name-based, text-match-only).
- **reachability** (from file 03): navigation_url, menu_accessible, menu_path, roles_required, entry_type, reachability_evidence.
- **trigger details** when applicable (from file 04).
- **priority_hint**: coarse (for example high, medium, low) with the reasons. A hint only; triage owns final ranking.
- **status relative to baseline**: new, unchanged, changed or removed since the previous scan.
- **allowlist status**: not allowlisted, or allowlisted with reason, approver and expiry.
- **related_pois**: grouped fragments of the same suspected behavior.

## Scan-level output

- Application profile (file 05) and its changes since the last scan.
- Coverage report: files parsed, files skipped, files that could not be analyzed, and the precision level reached per language. Nothing is reported clean for an area that was not analyzed.
- Counts by category, priority hint and exposure (menu-exposed, hidden, role-restricted, no entry point).
- Run metadata: tool and rule versions, model versions used, timing, and a content hash of the scanned source.

## Baseline and diff mode

- Every scan can be compared against the previous scan of the same application.
- Output distinguishes new, changed, unchanged and removed POIs.
- The purpose is to catch a backdoor introduced in a single change, and to keep review volume manageable across thousands of applications.
- A full scan is always available; diff is a view, never a substitute for the full scan results.

## Allowlist

- Approved utilities and known-good patterns can be suppressed from review queues.
- Each allowlist entry needs: the POI ID or match rule, a reason, the approver, and an expiry date.
- Allowlisted POIs are still recorded and visible; they are only marked, never deleted.
- Expired entries automatically return the POI to review.
- If the underlying code changes, the allowlist entry no longer matches and the POI returns for review.

## Delivery

- Machine-readable output (JSON with a published schema) for the triage agent and other consumers.
- Human-readable report per application for reviewers.
- Output is append-only and versioned; earlier scan results are never overwritten.
