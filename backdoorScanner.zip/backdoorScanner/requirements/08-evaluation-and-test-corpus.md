# 08 Evaluation and Test Corpus

Author: Surya

Without measured detection rates we cannot know whether the scanner works. This file sets the requirement for a test corpus and the metrics.

## Primary metric: miss rate

Because the principle is to minimize false negatives, the headline number is **recall per category**: of the planted or known suspicious behaviors, what fraction produced a POI. Precision matters for reviewer workload but is secondary.

## Corpus

Build a labeled corpus of source code with known ground truth:

1. **Seeded samples:** small applications in Java, Python, Node.js, Go and .NET with deliberately planted behaviors from every category in the POI catalog (file 02) and every trigger family in file 04. Each seed has a label: category, technique, location, and whether it is menu-exposed, hidden or role-restricted.
2. **Technique variants:** the same behavior written many ways (different APIs, obfuscation levels, split across functions or files, behind reflection) to test depth of detection.
3. **Time-bomb variants:** many date and time techniques, including hardcoded and computed dates, elapsed-time triggers, remote time sources, user-existence triggers and environment checks.
4. **Benign look-alikes:** legitimate code that resembles suspicious code (an admin export feature, a real SMTP notification, a scheduled cleanup job) to measure false positive load and test the allowlist.
5. **Real or historical cases:** where available and approved, sanitized real internal cases or public malicious-code examples, including supply-chain examples (malicious install scripts, typosquats).
6. **Framework coverage:** menu, URL and role discovery tests across the main frameworks per language, including unfamiliar or custom ones to test the fallback and the intelligence layer.
7. **Hostile content:** files containing prompt-injection text, malformed archives, huge files, odd encodings and symlink tricks to test the safety rules.

## What is measured

- Recall and precision per category and per technique, per language.
- Reachability accuracy: correct navigation URL, menu_accessible and roles versus ground truth.
- Application profile accuracy: languages, frameworks and entry points.
- Layer comparison: what Layer 1 alone finds versus what the intelligence layer adds, and the false positive rate of model-added POIs.
- Degradation behavior: results when parsing or call graphs are unavailable.
- Diff correctness: a single injected change is flagged as new in the next scan.
- Stability: the same input gives the same POI IDs.
- Cost and time per application and per million lines of code.

## Gates

- A release of rules, adapters or prompts must not lower recall in any category below the agreed threshold.
- Thresholds are set per category after the first baseline run, before the scanner is used on production applications. Owners and sign-off are listed in file 10.

## Ongoing measurement

- Reviewer feedback on each POI (useful, benign, duplicate) is captured to tune priority hints and allowlists.
- Periodic red-team exercise: a security team member plants new behavior in a copy of a real application and checks whether the scanner finds it.
- Corpus grows whenever a miss is found in the field.
