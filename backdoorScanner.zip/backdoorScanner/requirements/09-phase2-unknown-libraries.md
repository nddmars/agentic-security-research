# 09 Phase 2: Unknown Libraries

Author: Surya

Status: phase 2 requirement. Not part of the first release, but the phase 1 design must leave room for it.

## Why

Libraries that no tool has ever scanned are a risk: nobody has looked at them, and they can carry backdoors or vulnerabilities. A library that is unknown to open source analysis sources is therefore itself a point of interest.

## Requirement

1. **Inventory:** the scanner builds a complete list of third-party libraries per application from manifests, lock files, build files and vendored code (name, version, ecosystem, source registry or URL, hash where available). The inventory is part of the application profile (file 05) and is already produced in phase 1.
2. **Lookup:** for each library and version, query an open source analysis source (for example a software composition analysis service or public package and vulnerability databases) to learn whether it is known.
3. **Unknown means POI:** a library that returns unknown, an unrecognized version, a mismatched hash, or a registry or location that is unusual becomes a POI in the supply-chain category.
4. **Handoff:** unknown libraries are sent to a **separate library analysis service**, which checks them for vulnerabilities and malicious behavior and returns a result.
5. **Record the result:** the scanner stores the service's verdict, evidence reference and date on the POI and on the application profile.

## Boundaries

- The library analysis service is **separate** from the scanner. It has its own design, owner and lifecycle.
- The scanner only defines and calls the **interface**: request (library identity, ecosystem, version, hash, artifact or source location, application context) and response (status, findings, evidence references, confidence, analysis date).
- The scanner does not analyze library internals itself in this phase.
- The scanner continues without waiting if the service is slow or down: the POI stays open with status "analysis pending", and is never marked clean by default.

## Additional requirements

- Cache results per library and version so the same library is not re-analyzed for every application.
- Re-check known-good results periodically, because a library version can be reported malicious later.
- Distinguish library categories: public registry packages, internal shared libraries, vendored copies and modified copies of well-known libraries.
- Show which applications use an unknown or flagged library, so a bad library can be traced across the enterprise quickly.
- Apply the same safety rules as file 07: never execute library code during analysis in the scanner.

## Open items for design

- Which open source analysis source or sources to use and their coverage.
- Interface style (synchronous, asynchronous, queue) and the service level expected.
- Ownership of the library analysis service.
