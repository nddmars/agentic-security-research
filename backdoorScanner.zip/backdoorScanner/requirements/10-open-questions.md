# 10 Open Questions

Author: Surya

Items to settle before or during the design phase. Status of each item (answered, proposed default, still open) is tracked in `../design/13-rollout-and-decisions.md`.

## Inputs and access

1. How is source delivered to the scanner for each application: build-artifact archive, repository clone, or both? (The triage design uses an archive from the pipeline.)
2. How are applications identified and mapped to owners and teams?
3. What is the expected scan trigger: every release, nightly, on demand, or on every merge?
4. How large is the first rollout (pilot set of applications) and which languages come first?

## Detection scope

5. Priority order of the POI categories for the first release.
6. Which categories need the intelligence layer in the first release and which can be rules only?
7. Treatment of generated code, vendored code, test code and build output: scan, scan with lower priority, or skip with a recorded reason?
8. Mobile applications (Swift, Kotlin, others): which phase, and which adapters?
9. Handling of binaries and compiled artifacts without source.

## Reachability

10. For database-driven menus, is there any way to obtain the menu data, or does the scanner record unknown?
11. How much front-end analysis is required (templates and bundles) versus back-end routes only?
12. How should role names be normalized across applications?

## Intelligence layer

13. Which models are approved for this scanner and for which steps? (The triage design already approves Claude and Gemini with secret redaction.)
14. Cost budget per application and per quarter, and what happens when the budget is reached.
15. Is a second model required for high-priority POIs?

## Review workflow

16. Who reviews POIs: the central security analyst team, application owners, or both?
17. Priority hint scale and what the review service-level targets are.
18. Allowlist approval: who may approve, what maximum expiry, and how is it audited?
19. How and when will the triage agent be invoked on POIs (automatic, on demand, only for certain priorities)?

## Output and integration

20. Where do results live (database, object store, dashboard) and who can access them?
21. Required retention of reports and evidence snippets.
22. Dashboard needs: per application, per category, per scan, trends, diff view.
23. Integration with ticketing: none in phase 1, as with the triage design, or required?

## Quality

24. Recall thresholds per category and who signs them off.
25. Source of the first test corpus and who builds the seeded samples.
26. Who runs the periodic red-team check?

## Phase 2

27. Choice of open source analysis source for unknown libraries.
28. Ownership, interface and service level of the separate library analysis service.

## Platform

29. Hosting: OpenShift as in the triage design, or elsewhere?
30. Whether the scanner shares infrastructure with the triage agent or runs separately.

## Decisions already made (for reference)

- Scanner and triage agent are separate projects; the scanner is independent of Checkmarx.
- Two-layer design: deterministic analysis plus intelligence layer; the model never removes rule-found POIs.
- Coarse priority hint only; final ranking belongs to triage.
- Baseline and diff, allowlist with expiry, supply-chain POIs, concealment techniques and the test corpus are in scope.
- Unknown library analysis is phase 2 and handled by a separate service.
