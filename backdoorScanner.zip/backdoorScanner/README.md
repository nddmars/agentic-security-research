# backdoorScanner (POI scanner): design pack

Author: Surya
Status: Design v1.2, consolidated 2026-11-12 with the voice decisions. Ready for a coding agent: start with `CODING-AGENT-BRIEF.md`.

## Folder map

| Path | Content |
|---|---|
| `CODING-AGENT-BRIEF.md` | Start here: reading order, fixed decisions, first tasks, rules |
| `requirements/` | Original requirements 01 to 10 (scope, POI catalog, reachability, time bombs, profile, output, safety, evaluation, phase 2, open questions) |
| `design/00` to `13` | Architecture, data model, acquisition, detection, reachability, model layer (now phase 3), similarity, state, platform, output/API, safety, library service, modules, rollout and decisions |
| `design/14-tech-spec.md` | Technical specification: stack and libraries |
| `design/15-ui-and-administration.md` | UI screens, roles, authentication, API tokens, preferences, reports |
| `design/16-rules-and-engine.md` | Pluggable detection engine; rules, presets, enablement in Git |
| `design/17-state-model-v2-and-auto-marking.md` | Configurable workflow, severity, suppression, similarity-based marking |
| `design/18-model-review-module-and-retention.md` | Separate model review module (phase 3), archive script |
| `design/19-test-bed.md` | Test bed: seeded apps and open-source projects |
| `reference/` | Earlier pending notes and the custom-rules context search note |

## Status of inputs

Needed from Surya: YARA rules (not blocking), Active Directory method and group mapping, owner names, open-source list approval, Legal review of the Semgrep rules license. Not needed: sample zips, Checkmarx sample. See `design/13` sections 5 and 6.
