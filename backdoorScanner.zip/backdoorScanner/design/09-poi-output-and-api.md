# 09 POI Output, API, Triage Handoff and Oversight

Author: Surya
Status: Design v1.2 (2026-11-12). Stage 6 (assembly) is specified here. States and severity come from the configurable workflow (17); screens are specified in 15.

## 1. Stage 6: Assembly

Inputs: candidates, reachability, intelligence outputs, similarity summaries, profile, coverage. Steps, in order:
1. **Merge** Layer 1 candidates with reachability; apply intelligence additions and enrichments (05 guardrails: additive only).
2. **Fingerprint** every POI (07), **recurrence matching** against the project's fingerprints, create or update `poi_fingerprints` and state rows.
3. **Baseline diff** against `baseline_scan_id` (the previous *complete* scan of the project): `new`, `unchanged`, `changed`, `removed`.
4. **Suppression** evaluation: active rule suppressions are applied (17 section 4); suppressed POIs are recorded and marked, not dropped.
5. **Priority hint** (section 3).
6. **Group** related POIs (`related_pois`).
7. Write `scan_pois`, `poi_evidence`, the machine-readable report (JSON), the human-readable report, the coverage report and run metadata; mark the scan `complete` or `partial`.
8. Update lifecycle (last build/scan times), publish `ScanCompleted`.

Step 7 is one database transaction per scan plus the artifact upload; the scan is visible to consumers only after commit (append-only, never partially visible).

## 2. POI record (JSON, published schema `poi-record.v1.schema.json`)

```json
{
  "schema_version": "1.0",
  "poi_id": "hex fingerprint",
  "scan_poi_id": "uuid",
  "scan_id": "uuid", "application_id": "uuid", "component_id": "uuid",
  "project_id": "uuid", "profile_version": 7,
  "category": "A.command_execution",
  "technique": "process_builder_or_runtime_exec",
  "title": "Command built from request parameter and executed",
  "description": "Neutral description of what the code does.",
  "location": {"path": "src/main/java/.../AdminTool.java", "start_line": 88, "end_line": 112,
               "function": "runDiag", "language": "java"},
  "evidence": [
    {"snippet_id": "S1", "role": "match", "path": "...", "start_line": 90, "end_line": 94, "text": "...masked..."},
    {"snippet_id": "S2", "role": "route", "path": "...", "start_line": 40, "end_line": 41, "text": "..."}
  ],
  "origin": "rule | ast_query | callgraph | text | intelligence",
  "rule_id": "CMD-EXEC-JAVA-001",
  "precision": "full_analysis | ast_local | name_based | text_only | intelligence",
  "confidence": "high | medium | low",
  "reachability": {
    "navigation_url": "/admin/diag/run",
    "entry_type": "web_route",
    "menu_accessible": "no",
    "menu_path": [],
    "roles_required": {"status": "known", "roles": ["ROLE_SUPPORT_L3"], "normalized": ["support_l3"], "flags": ["rare_role"]},
    "exposure_class": "hidden_with_url",
    "all_entry_points": [{"url": "...", "entry_type": "web_route", "precision": "name_based"}],
    "evidence_snippet_ids": ["S2", "S3"]
  },
  "trigger_details": null,
  "priority_hint": {"level": "high", "reasons": ["command_execution", "hidden_with_url", "rare_role"]},
  "business_likelihood": "likely_utility_or_hidden",
  "baseline_status": "new",
  "recurrence": "new",
  "state": {"current": "to_verify", "severity": null, "assigned_to": null},
  "suppression": {"status": "none"},
  "related_pois": ["hex..."],
  "similarity": {"exact_occurrences": 3, "fuzzy_occurrences": 1, "other_projects": [{"project_id": "...", "state": "not_exploitable"}]},
  "injection_indicator": false
}
```

Secrets in `text` are masked (`****`); live secrets are reported by location and type only.

Trigger POIs add `trigger_details`: `trigger_family`, `technique`, `condition_snippet_id`, `guarded_action {category, snippet_id}`, `value_origin`.

## 3. Priority hint (coarse)

Computed in code from facts, then optionally raised (never lowered) by intelligence:
- Base level per category/technique from rule metadata.
- Adjustments: exposure class (`hidden_with_url`, `dormant`, `no_url_entry` with dangerous category raise; `menu_all_roles` lowers for non-dangerous categories only), rare role or hardcoded principal (raise), trigger with dangerous guarded action (raise), file class `test|generated` (lower one level, except concealment category D, which never lowers), precision `text_only` (confidence lowered, priority unchanged), `injection_indicator` (raise).
- Output `high | medium | low` plus reasons list. It is a hint; final ranking belongs to triage or a human.

## 4. Scan report

Machine-readable `scan-report.v1.json`: scan attributes, profile summary and changes, coverage report, counts by category/hint/exposure/recurrence/baseline status, intelligence stats (partial or not, model versions), ruleset and tool versions, content hash, list of `poi_id`s. Human-readable HTML/PDF per application scan, generated from the same data.

## 5. API (`poi-api`, REST JSON, authenticated, role-based)

| Endpoint | Purpose |
|---|---|
| `GET /applications`, `/components/{id}`, `/projects/{id}` | Hierarchy and lifecycle, with `_cmdb` vs `_ours` values and `differs` |
| `GET /scans?component=&from=&to=&status=` ; `GET /scans/{id}` ; `GET /scans/{id}/report` | Scan data and reports |
| `GET /scans/{id}/pois?category=&hint=&exposure=&baseline=&state=` | Filtered POIs of a scan |
| `GET /pois/{poi_id}` ; `GET /pois/{poi_id}/history` ; `GET /pois/{poi_id}/occurrences` | Current record, history, similarity occurrences |
| `PATCH /pois/{poi_id}/state` (body: `to_state`, `comment`, `expected_version`) | Reviewer state change (history written) |
| `POST /pois/{poi_id}/assign`, `/comment` | Assignment, comment |
| `GET/POST/DELETE /suppressions` | Suppress by rule ID with scope, reason, optional expiry; role permission enforced |
| `GET/PUT /admin/workflow`, `/admin/roles`, `/admin/severities`, `/admin/api-access` | Workflow, roles, severities, API access policy (administrator role) |
| `GET /similarity-review`, `POST /similarity-review/{batch}/approve|reject|override` | Lead review of automatically proposed decisions (17 section 5) |
| `GET /rules`, `/presets`, `/rules/{id}/history` | Rules management backed by Git (16) |
| `GET /components/{a}/similar`, `/components/{a}/vs/{b}` | Proxy to the similarity service |
| `GET /profiles/{component}/versions`, `/versions/{n}/diff` | Profile history and change |
| `POST /scans` (intake) | Pipeline trigger (service account only) |
| `GET /export/pois?...` | CSV/JSON/SARIF export (SARIF 2.1.0; our extra fields such as reachability, state and fingerprint in `properties`; the own JSON record remains the full format) |

The published OpenAPI spec is generated from the Pydantic models. Pagination, filtering and rate limits are standard; every write is audited.

## 6. Triage handoff

The POI record above is the triage input contract. Interface **[PROPOSED]**: the scanner publishes `POIReady` events (or the triage agent pulls `GET /scans/{id}/pois`) and accepts a triage result through `POST /pois/{poi_id}/triage-result` with `verdict`, `confidence`, `reasons`, `evidence_refs`, `triage_agent_version`. The result is stored in history as a *proposed* state change (actor type `agent`). Invocation policy (open question 19, **[PROPOSED]**): not automatic in phase 1; phase 3 invokes triage on `high` hints first. The context-gathering recipes of cxtriage for pattern-only findings map directly: a POI is a pattern-style finding (file, line, match, no flow) with extra reachability facts.

## 7. Dashboard and oversight views

1. **Portfolio:** applications and components by lifecycle, type, last scan age, coverage percent, open POIs by state and hint.
2. **Application/component:** POI list with filters (category, hint, exposure class, state, baseline status, recurrence), trend over scans.
3. **Scan diff:** new, changed, removed POIs between two scans; "introduced in this scan" view for the single-change backdoor case.
4. **POI detail:** evidence snippets, reachability chain with menu path and roles, trigger details, similarity occurrences with states elsewhere, full history.
5. **Review queue:** the **MCD-Ops** group queue (all POIs land here; assignment to individuals is made from it), filtered by hint, assignment, age against the review SLA (**[PROPOSED]** high 2 business days, medium 5, low 15, to be set by the team).
6. **Governance (oversight):** CMDB differences (`differs` flags by field: type, owner, lifecycle, criticality), components with builds but no CMDB record, components inactive in CMDB but active here and the reverse, profile changes (new outbound client, new endpoint), lifecycle changes, suppressions nearing expiry, reviewer throughput, model-added POI precision.
7. **Coverage:** unparsed/skipped files by language and reason, scans marked `partial`, `intelligence_partial` rates.
8. **Similarity:** shared-function lists and component overlap in both directions.
9. **Phase 2:** unknown and flagged libraries, applications affected.

Roles are created and edited in the administration panel and mapped to screens, actions and workflow transitions (15, 17). Seed roles: `analyst`, `reviewer`, `admin`, `auditor`. Access to evidence snippets is restricted and logged.

## 8. Acceptance criteria

- Every record validates against the published JSON Schema in CI.
- Same input produces the same `poi_id`s and the same record contents except timestamps and scan IDs.
- A consumer reading while a scan is being written never sees a partial scan.
- State changes through the API produce exactly one history row and respect `expected_version`.
- Suppressed POIs remain visible under the `suppressed` filter; expired or lifted suppressions return them to the queue.
- SARIF export validates against the SARIF 2.1.0 schema.
