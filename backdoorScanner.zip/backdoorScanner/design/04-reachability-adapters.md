# 04 Stage 4: Reachability (Routes, Menus, Roles, Call-Chain Linking)

Author: Surya
Status: Design v1.

## 1. Purpose

For every candidate POI, answer: how can this code be reached, is it exposed through the application's own navigation, and who can reach it. Output the six facts from requirements 03 (`navigation_url`, `menu_accessible`, `menu_path`, `roles_required`, `entry_type`, `reachability_evidence`) plus a precision tag.

## 2. Inputs and outputs

Inputs: candidates (03), function index and call graph (03), component profile (02), workspace files. Output: `reachability.jsonl` (one record per candidate), `routes.json`, `menus.json`, `role_rules.json` (per scan artifacts that are also summarized into the profile).

## 3. Adapter interface

One adapter per framework family. Adapters are plugins discovered by name; each declares the profile signals it needs.

```python
class FrameworkAdapter(Protocol):
    name: str                        # "spring_mvc", "django", "express", ...
    languages: tuple[str, ...]
    def matches(self, profile: ComponentProfile) -> float: ...        # 0..1
    def extract_routes(self, ctx: ScanContext) -> list[Route]: ...
    def extract_entry_points(self, ctx: ScanContext) -> list[EntryPoint]: ...  # jobs, listeners, CLI, startup
    def extract_menus(self, ctx: ScanContext) -> list[MenuEntry]: ...
    def extract_role_rules(self, ctx: ScanContext) -> list[RoleRule]: ...
```

Data classes: `Route(method, url_pattern, handler_function_id, file, line, evidence_snippet, auth_markers)`, `MenuEntry(label, target_url, parent_path, file, line, visibility_conditions, source_kind)`, `RoleRule(scope: route|function|prefix|global, roles, expression, file, line, kind: annotation|middleware|filter|guard|inline|config)`.

Every adapter ships with fixtures (small apps) and runs in CI against the corpus.

## 4. What each adapter looks for (starting set)

| Language | Framework | Routes | Roles/auth | Menus (typical) |
|---|---|---|---|---|
| Java | Spring MVC / Boot | `@RequestMapping`, `@GetMapping` and siblings, class-level prefix plus method path, context path from properties | `@PreAuthorize`, `@Secured`, `@RolesAllowed`, `SecurityFilterChain` / `antMatchers`/`requestMatchers` rules, method security | Thymeleaf/JSP templates with nav fragments, static menu JSON, front-end router |
| Java | JAX-RS, servlets, Struts | `@Path`, `web.xml` servlet mappings, `struts.xml` actions | `@RolesAllowed`, `web.xml` security constraints | JSP includes, Struts menu config |
| Python | Django | `urls.py` `path`/`re_path`/`include` trees | `login_required`, `permission_required`, mixins, DRF permission classes | templates (`{% url %}` in nav includes), admin site |
| Python | Flask / FastAPI | `@app.route`, blueprints, `@router.get`, `include_router` | decorators, `Depends(...)` security dependencies, `flask_login` | Jinja templates, front-end router |
| Node.js | Express | `app.get/post/...`, `router.use` mounting | middleware chain (`passport`, JWT, custom role middleware) | EJS/Pug/handlebars templates, SPA router |
| Node.js | NestJS | `@Controller` prefix plus `@Get` etc. | `@UseGuards`, `@Roles`, guards | SPA router |
| Node.js | Next | file-based routing (`pages/`, `app/`), API routes | middleware, `getServerSideProps` checks | components with `Link`/nav config |
| Go | net/http, gin, echo, chi | `http.HandleFunc`, `r.GET`, `e.GET`, `r.Get`, group prefixes | middleware wrapping, group-level auth | templates, SPA |
| .NET | ASP.NET MVC / Web API | `[Route]`, `[HttpGet]`, conventional routing in `Program.cs`/`Startup.cs`, minimal APIs `MapGet` | `[Authorize(Roles=...)]`, policies, global filters | Razor `_Layout`/nav partials, Blazor `NavMenu` |
| .NET | Razor Pages, Blazor | `@page` directives, `@page` routes | `[Authorize]`, `AuthorizeView` | `NavMenu.razor` |
| Front end | React, Angular, Vue (all stacks) | router config (`<Route>`, `routes: [...]`, `createRouter`) | route guards (`canActivate`, `beforeEach`) | nav components, sidebar config arrays, menu JSON |

Non-HTTP entry points: scheduled jobs (`@Scheduled`, cron, Quartz, Celery beat, `node-cron`, hosted services), message listeners (`@KafkaListener`, `@RabbitListener`, JMS, SQS consumers, `Consumer`), CLI commands (`main`, argparse/click/cobra entry), startup hooks (`@PostConstruct`, `CommandLineRunner`, `IHostedService`, `init()`).

## 5. Linking a POI to its entry points

1. Find the POI's enclosing function ID.
2. Walk the call graph **upward** (callers) with a depth cap **[PROPOSED]** 12, collecting every path that reaches a route handler, job, listener, CLI command or startup hook. Cap the number of paths per POI **[PROPOSED]** 20 and record truncation.
3. For each reached entry point, assemble the navigation URL (context path + class prefix + method path, with parameters normalized as `{param}`), the entry type, and role rules that apply on the path (route-level, prefix-level, global filters, inline checks in functions on the chain).
4. Precision of the link = weakest edge on the chain (`full_analysis` only when every edge resolved uniquely; otherwise `name_based`).
5. No path found: `entry_type = unreachable`, reported as dormant code (flag from requirements 03), unless the function is a framework callback the adapters do not know (then `unknown`, and the unusual-candidate marker goes to stage 5).
6. A POI that is itself a route handler, job, or listener is its own entry point.

If several entry points reach one POI, the record lists all of them; the **exposure class** takes the most exposed one for menu status and lists the rest.

## 6. Menu accessibility

1. Collect `MenuEntry` records from templates and front-end sources.
2. Match each entry's `target_url` to routes by normalized pattern (exact first, then parameterized, then prefix). A match marks that route `menu_accessible = yes` with `menu_path` (the chain of labels from the root menu entry).
3. Conditional menus (rendered only for roles, features or flags) add `visibility_conditions`; these feed `roles_required` for the menu path and are recorded as evidence.
4. If menu data is database-driven or loaded from a remote service, `menu_accessible = unknown`, with the reason `db_driven_menu` and the seed table or loader function cited when found. **[PROPOSED]** Open question 10: seed data in the repository (SQL, JSON, migrations) is parsed when found.
5. Utilities exposed through the menu stay flagged (requirements 03): menu exposure lowers the priority hint for plain business categories, never removes the POI, and does not lower it for categories A (command execution, free-form DB query) or E.

## 7. Exposure classes (output field `exposure_class`)

`menu_all_roles`, `menu_restricted_roles`, `hidden_with_url`, `no_url_entry` (job, listener, CLI), `dormant` (no entry point), `unknown`. The class drives priority hint adjustments in assembly (09 section on hints).

## 8. Role normalization

Roles are recorded exactly as written (`raw`) plus a normalized token (lowercase, prefix `ROLE_` and separators removed) **[PROPOSED]** for cross-application grouping. A mapping table for synonyms is maintained by analysts (open question 12). Rare-role finding: a role string that appears on fewer than N routes in the application (N configurable) is marked `rare_role`; a hardcoded user or IP in a role check is marked `hardcoded_principal`.

## 9. Generic fallback and intelligence assist

When no adapter matches (`matches < threshold`) or adapters return no routes for a component with source code that looks like a service, stage 4 runs the generic discovery:
1. ripgrep for route-table shapes (URL-looking string literals near handler references, annotations containing paths, decorators with strings starting with `/`), menu-shaped structures (arrays/objects with `label`/`title` and `url`/`path`/`href`), and role-check shapes (`hasRole`, `isInRole`, `roles.includes`).
2. Hand the hits to stage 5 task T2 (05) to confirm and complete the route/menu/role tables, with cited snippets.
3. All fallback-derived facts carry the `intelligence` precision tag and are shown separately from adapter-derived facts.

## 10. Performance

Adapters work from the per-file facts stage 3 already extracted where possible; they only re-parse files that contain route, menu or role constructs. Menu matching is in memory per scan. Result size is capped per POI (paths, roles), with truncation flagged.

## 11. Acceptance criteria

- Reachability accuracy (URL, menu status, roles) on the framework corpus meets thresholds agreed in phase 0, per framework.
- Dormant, hidden, role-restricted and menu-exposed seeds are classified correctly.
- Unknown framework test: the fallback finds routes and menus in a custom framework with cited evidence, or returns `unknown` (never a confident wrong answer).
- Every POI has all six reachability fields, with `unknown` recorded explicitly where not determinable.
