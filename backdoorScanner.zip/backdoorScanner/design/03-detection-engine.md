# 03 Stage 3: Deterministic Detection Engine

Author: Surya
Status: Design v1.2 (2026-11-12). The rule engine is pluggable (16): Semgrep default, Opengrep or own tree-sitter rules as fallback. Other technology choices are confirmed by the phase 0 spikes (13).

## 1. Purpose and guarantees

Stage 3 is the exhaustive, repeatable layer. It processes every file in the inventory, applies rules, and outputs **candidate POIs** with evidence and precision tags, plus the function index for similarity and the per-file coverage record.

Guarantees: (1) every file is accounted for (`parsed`, `text_only`, `skipped` with reason, `error`); (2) same input + same ruleset version = same output, in the same order; (3) a failure on one file is recorded and the scan continues; (4) no model is used here.

## 2. Technology choices **[PROPOSED]**

| Need | Choice | Why |
|---|---|---|
| Parsing, all five languages, per file | **tree-sitter** with Python bindings | Low memory, per file, fast, grammars for Java, Python, JavaScript/TypeScript, Go, C#; fits whole-repo scanning of 12 GB repositories |
| Text, config, string and file-name search | **ripgrep** (`rg --json`) | Fast across the repository; used for config files, resource files, scripts, and unparsed files |
| Call graph | **Lightweight, name-based graph built from tree-sitter** (definitions and call sites, per language), upgraded by framework knowledge | Enough for call-chain linking at scale; precision-tagged `name_based` |
| Heavy call graph / data flow | **Joern** as an optional per-language upgrade behind a size cap | Evaluated in spike S2; not required for phase 1 |
| Rule engine | **Pluggable `DetectionEngine`** (16): default Semgrep engine and rules (internal use, Legal to confirm); fallback Opengrep with own rules or own tree-sitter queries; plus existing YARA rules and ripgrep text rules. All engines emit the same `RawHit` | Calls that matter (database, command execution, file upload/download, network) are language and framework specific; a rule library encodes them. tree-sitter alone only parses. Own YAML rule metadata (category, technique, `logic_version`, precision, fixtures) wraps every rule regardless of engine |

Note: this differs from cxtriage, where Joern is the only analysis engine. The scanner must cover every file of every repository, so a rule engine plus per-file tree-sitter enrichment is the base. For each engine hit in a source file, tree-sitter finds the enclosing function and produces the function IDs, call-graph links and route annotations (16 section 1).

## 3. Processing steps

1. **Load** the inventory and profile. Choose rule packs by language and detected frameworks. Always include generic packs.
2. **Parse** each source file with tree-sitter (parallel workers; per-file timeout and memory cap; failures downgrade the file to `text_only` and are logged). Keep the syntax tree in memory only for the current file; store extracted facts, not trees.
3. **Extract per-file facts** in one pass: imports, function/method/class definitions with line ranges, call sites (callee name, receiver, arguments as literal/identifier/other), string literals (with entropy and decoded-form hints), annotations/decorators, conditions (`if`/ternary/switch expressions with their operands), assignments of constants.
4. **Function index** for the similarity service: for each function, the normalized token stream and the IDs (06). Written to the database in batch.
5. **Apply rules**: run the configured `DetectionEngine` over the files (Semgrep by default), YARA and ripgrep text rules, and own tree-sitter queries; map every `RawHit` to the enclosing function with the parsed facts. Rules are loaded from a tagged release of the rules repository (16 section 3).
6. **Build the call graph** (name-based) from the facts, per language, resolving imports and receivers where possible; ambiguities produce multiple edges tagged `name_based`.
7. **Intra-function flow checks** (section 6) for condition-to-action links and sensitive-data-to-sink links.
8. **Mark unusual code** for stage 5: high-entropy strings, long decoded-then-used blobs, dynamic loading/reflection with non-literal names, unexplained outbound network use, functions never called but non-trivial. These markers become `unusual_candidates`, not POIs, unless a rule fires.
9. **Emit** candidate POIs, the call graph artifact, unusual candidates, per-file coverage, and rule execution stats.

## 4. Rule format

The metadata wrapper for every rule (also those executed by Semgrep or Opengrep) is YAML, versioned in Git, each with fixtures (positive and negative) that run in CI. A rule that has no fixtures cannot be merged.

```yaml
id: CMD-EXEC-JAVA-001
category: A.command_execution
technique: process_builder_or_runtime_exec
languages: [java]
kind: ast_query                # ast_query | text | yara | config | composite | callgraph
logic_version: 1               # bumped when match semantics change; a bump reopens affected POIs (07 section 3.1)
query: |                       # tree-sitter query (verify syntax and predicate support per binding version)
  (method_invocation
    object: (_) @recv
    name: (identifier) @fn
    (#match? @fn "^(exec|start)$"))
  @call
constraints:
  - recv_type_hint_any: [Runtime, ProcessBuilder]   # name-based type hint, best effort
evidence: {match: "@call", context_lines: 3}
precision: ast_local
priority_hint: high
tags: [capability]
fixtures: {positive: [fixtures/java/exec_1.java], negative: [fixtures/java/exec_benign_1.java]}
```

Composite rules chain others (for example "decoded blob" then "dynamic load" in the same function). `logic_version` is raised only when what the rule matches changes (pattern, constraints, exclusions); wording, tags and priority metadata changes do not raise it. `text` rules carry the ripgrep pattern, file globs, and exclusions. Every rule declares which `category` and `technique` it feeds, so the output stays inside the catalog. Adding a technique never changes the output schema.

### 4.1 Existing YARA rules

The team already has YARA rules. They become a rule kind, `yara`, run by the same engine:
- Each YARA rule file is wrapped by a small manifest (or uses the rule `meta:` section) that gives `category`, `technique`, `languages` (or file globs), `precision: text_only`, `priority_hint`, `logic_version` (default: hash of the rule body), and a mandatory fixture pair.
- YARA runs over file bytes/text, so it suits strings, encoded payloads, obfuscation markers, hardcoded indicators, suspicious file names and contents in resource, script and config files. It has no syntax tree, so it cannot see function boundaries, call sites or conditions; those stay with tree-sitter rules.
- A YARA match is mapped to the enclosing function through tree-sitter when the file is parsed (so the POI gets a function and a fingerprint); otherwise it is a file-level POI with the matched strings as evidence.
- Matched string values are masked when they look like secrets, same as everywhere.
- Libraries: `yara-python`, or YARA-X (not a drop-in replacement, different Python API) **(verify both: version, license, build availability on the worker image)**. Spike S1 includes a run of the existing rule set over the sample repositories to measure matches and runtime.
- The existing rules are regex signatures, point-of-interest regexes and filename regexes (stated 2026-11-12). Content regexes run as `yara` rules. **Filename regexes** are run by the engine against the file inventory (path and name), because YARA matches file content; if the rules already use YARA external variables for file names, they can run unchanged by passing the path at scan time. Each filename hit becomes a file-level POI (for example key stores, `.env`, backup, dump or script files in unexpected places).
- Open input: how many YARA rules exist and who maintains them; the existing rules are the one remaining input from Surya (not blocking the first build).

## 5. Rule library by category (starting set)

APIs are examples, not exhaustive; the coding agent expands each list per language from official API documentation, with analysts reviewing.

| Category | Detection techniques |
|---|---|
| A. Command and script execution | Java `Runtime.exec`, `ProcessBuilder`; Python `subprocess.*`, `os.system`, `os.popen`; Node `child_process.*`; Go `os/exec`; .NET `Process.Start`. Script invocation: string args ending `.sh`, `.ps1`, `.bat`, `.cmd`, interpreter names. Injection surface: argument built by concatenation or formatting from a variable |
| A. Dynamic code | `eval`, `exec`, `compile`, `Function(...)`, `vm.*`, `ScriptEngine`, `GroovyShell`, expression evaluators, `Assembly.Load`, `CSharpScript`, `Class.forName` with non-literal, reflection `invoke`, `plugin.Open` (Go) |
| A. Free-form DB query | Function taking a string/parameter that reaches `executeQuery`/`execute`/`query`/`Exec`/`SqlCommand`/`ExecuteSqlRaw` unchanged; endpoints named `query`, `sql`, `execute`; parameters named `sql`, `query`, `statement` |
| A. File upload / download | Multipart handlers (`MultipartFile`, `request.files`, `multer`, `FormFile`, `IFormFile`); download handlers returning `FileSystemResource`, `send_file`, `res.download`, `http.ServeFile`, `File(...)` with a path built from input |
| B. Outbound network/email | HTTP clients, raw sockets (`Socket`, `socket.socket`, `net.Dial`, `TcpClient`), SMTP/mail libraries; hosts hardcoded, from config, or from input. Hostname classification: internal pattern, public, IP literal, paste/file-sharing list |
| B. DNS exfiltration | Resolver calls (`InetAddress.getByName`, `socket.gethostbyname`, `dns.resolve`, `net.LookupHost`, `Dns.GetHostEntry`) with a computed hostname containing a variable/encoded part; TXT lookups |
| B. File dumps / shared drives | Writes to UNC paths, `/mnt`, `/net`, mapped drives, cloud SDK uploads, temp paths outside configured data dirs |
| B/H. Sensitive data to logs/files | Identifier names (`ssn`, `password`, `card`, `cvv`, `token`, `secret`), regexes for PAN (Luhn-checked) and SSN shapes in literals, flow from such identifiers into log, print, write or send calls within a function |
| C. Information gathering | Env/system property enumeration (`getenv()` without name, `os.environ` iteration, `System.getProperties`), host/user/process/interface enumeration, reads of credential and key file locations |
| D. Concealment | Base64/hex decode feeding an exec/load/eval; entropy above threshold on long literals; string assembly of sensitive names; XOR loops over literals; reflection with computed names; logging calls removed or wrapped in always-false conditions; payloads in comments (long base64 or code-like text in comments) |
| E. Hidden access | Hardcoded credentials and keys (secret regexes plus assignment context); magic header/parameter/user/IP comparisons that precede early return or privilege change; auth bypass shapes (`if user == "x": return allow`); routes with no auth annotation in an app that otherwise uses them |
| F. Time bombs and triggers | See section 7 |
| G. Supply chain | Install/build scripts (`postinstall`, `setup.py` cmdclass, Maven/Gradle exec plugins, MSBuild `Exec`, CI steps) that run commands, `curl|sh` shapes, downloads then execution; dependencies from git URLs, raw URLs, local paths, non-standard registries; look-alike names (edit distance against a popular-package list, phase 2 for external lists); runtime fetch-and-execute |

## 6. Flow checks (intra-function, name-based first)

- **Condition to action:** for each trigger condition (section 7), find the guarded block and classify its actions using the capability rules (delete, network, exec, privilege change, disable control). A trigger with a dangerous guarded action gets a higher priority hint; a trigger with an unclassified action is still recorded.
- **Value to sink:** a decoded or computed value reaching an exec/load/eval/send call in the same function. Cross-function links use the name-based call graph and carry `name_based`.
- **Sensitive identifier to log/file/send:** same-function assignment tracking over identifiers and simple expressions.
- Deeper inter-procedural data flow is out of scope for phase 1; the optional Joern upgrade (S2) can add it per language.

## 7. Time bomb and trigger rules (requirements 04)

Rule families, each with `technique` values:
- `date_time`: current-time APIs in conditions (`LocalDate.now`, `datetime.now`, `Date.now`, `time.Now`, `DateTime.Now/UtcNow`), comparisons with literal dates/epoch constants/weekday or month values, elapsed-time arithmetic, scheduler constructs (cron strings, `@Scheduled`, `schedule`, `setTimeout` with large delay, Quartz, `System.Threading.Timer`, `Task.Delay`), sleep-then-act, time taken from headers/remote/DB/file mtime/NTP, counters and thresholds persisted across runs.
- `account_identity`: conditions on specific user/employee/email/domain/tenant literals; existence or absence checks (`exists`, `findById == null`, `isEnabled`) directly guarding an action.
- `environment_host`: hostname, IP, domain, region, locale, timezone, env var or property comparisons; checks for debuggers, sandboxes, monitoring agents, files/registry keys/processes.
- `external_signal`: conditions on values fetched from remote files, DNS, web pages, queues or DB rows; magic header/parameter/file-name checks.
- `logic_bomb_structure`: branches with destructive, exfiltrating or privilege-changing actions and a rarely true condition (constant-heavy, equality on odd literals).
- Computed or obfuscated constants (date built from string pieces, arithmetic on epoch values) are matched by the arithmetic-on-literals pattern and pushed to stage 5 as unusual candidates when the rule cannot decide.

Output fields for trigger POIs: `trigger_family`, `technique`, `condition_snippet_id`, `guarded_action` (category and snippet), `value_origin` (hardcoded | computed | external).

## 8. Output of stage 3 (artifacts)

- `candidates.jsonl`: one candidate POI per line (rule ID, category, technique, location, snippets, precision, origin, trigger details).
- `functions.jsonl`: function index with IDs and call-site lists.
- `callgraph.json.zst`: name-based graph (nodes: function IDs; edges with precision tag).
- `unusual.jsonl`: stage 5 candidates with the reason marker.
- `coverage.json`: per file and per language coverage, rule stats, errors.

## 9. Performance and limits

- Process per file in parallel workers (process pool); the unit of retry is a batch of files, so a worker crash is resumable.
- Limits per file (time, size, tree depth); very large generated files are text-scanned only and recorded as such.
- Repository sharding for very large repos: split the file list into shards processed by separate tasks; merge in the assemble stage.
- Target **[PROPOSED]**: 1 million lines in under 10 minutes on a worker of 4 CPUs / 8 GB, to be measured in spike S1.

## 10. Acceptance criteria

- Every rule has fixtures; CI runs all fixtures per language.
- Recall per category on the seeded corpus meets the agreed thresholds (10).
- A killed worker mid-stage resumes without duplicating or losing candidates.
- Two runs on the same input produce byte-identical `candidates.jsonl`.
- Unparseable and oversized files appear in the coverage report with reasons.
