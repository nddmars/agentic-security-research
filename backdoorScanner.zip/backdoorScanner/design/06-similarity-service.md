# 06 Similarity Service

Author: Surya
Status: Design v1. A separate service (decision). Algorithms and thresholds are **[PROPOSED]** until tuned on real code in spike S4.

## 1. Purpose

1. Give every function a stable ID that survives formatting and line shifts, so POI fingerprints survive normal edits (07).
2. Find reused code across components so shared functions are analyzed once and reviewers see where else a POI's code appears.
3. Report component-to-component similarity as a percentage in both directions, with the list of shared functions.

It records **metadata only**. It never carries a triage decision from one place to another (decision). Consumers decide later what to do with the data.

## 2. Function normalization (done in stage 3, from tree-sitter)

Input: the function's syntax tree. Output: a token stream.
- Remove comments, whitespace, and line numbers.
- **Keep identifier names** (variables, parameters, called function names, member names), because reused code usually keeps them (decision).
- Keep operators, keywords and literals' **types** and, for short string/number literals (up to a length cap **[PROPOSED]** 64), their values; replace longer literals with a type tag plus length bucket. This makes a changed URL or password literal change the exact ID, which matters for security.
- Normalize language-trivial variation: parenthesization, trailing commas, `this`/`self` prefix, import aliases.
- Functions under a minimum size **[PROPOSED]** (fewer than 15 tokens, simple getters/setters, constructors that only assign, generated accessors) get IDs but are excluded from component similarity percentages and fuzzy matching (counted separately as `trivial`).

## 3. The IDs

| ID | Definition | Use |
|---|---|---|
| `exact_id` | SHA-256 (truncated to 128 bits) of the normalized token stream with identifiers kept | POI fingerprint, exact reuse |
| `structure_id` | Same, with identifiers replaced by positional placeholders (`v1`, `v2`, `f1`) | Detect renamed copies |
| `fuzzy_sig` | MinHash signature (**[PROPOSED]** 128 permutations) over k-token shingles (k = 5) of the normalized stream | Near-duplicates after small edits |

Line numbers are stored on `scan_functions` only as location attributes and never enter an ID.

## 4. Matching

- **Exact:** equality on `exact_id`.
- **Renamed:** equality on `structure_id` and different `exact_id`.
- **Fuzzy:** estimated Jaccard from MinHash >= threshold **[PROPOSED]** 0.8, found through LSH banding (**[PROPOSED]** 32 bands x 4 rows, tuned for the threshold), then verified by comparing the actual token sets before recording a match.
- Matches are recorded with `match_type` (exact, renamed, fuzzy), the score, and both function locations.

Storage: `function_lsh_bands(band_id INT, band_hash BIGINT, function_ref ...)` with an index on `(band_id, band_hash)`; candidate pairs are verified in the service. Only non-trivial, non-vendored-by-default functions are indexed; vendored functions can be indexed separately because copy-pasted library code is a useful signal.

## 5. Component-level similarity

For components A and B, using their latest complete scans:
- `A_to_B` = (number of A's non-trivial functions with an exact or renamed or fuzzy match in B) / (A's non-trivial functions).
- `B_to_A` likewise. The two numbers differ (for example 80% and 10%) and both are stored.
- Report separately for exact-only and with-fuzzy, so analysts can see how much is verbatim copy.
- Store the shared functions: `(component_a, component_b, function_a, function_b, match_type, score)`.

```sql
CREATE TABLE component_similarity (
  component_a UUID, component_b UUID, scan_a UUID, scan_b UUID,
  a_functions INT, b_functions INT,
  a_to_b_exact NUMERIC, a_to_b_with_fuzzy NUMERIC,
  b_to_a_exact NUMERIC, b_to_a_with_fuzzy NUMERIC,
  computed_at TIMESTAMPTZ, PRIMARY KEY (component_a, component_b)
);
CREATE TABLE shared_functions (
  component_a UUID, component_b UUID, function_a_exact_id BYTEA, function_b_exact_id BYTEA,
  match_type TEXT, score NUMERIC, path_a TEXT, path_b TEXT
);
```

## 6. Operation

- Triggered by an event after stage 3 completes for a scan. It never blocks the scan.
- Incremental: only functions with new `exact_id` values are inserted and matched. Component pairs are recomputed only when the matched set changes, and only for pairs that share at least one function (found via the index, not by scanning all pairs).
- Query API: `GET /functions/{exact_id}/occurrences`, `GET /components/{id}/similar?min=0.2`, `GET /components/{a}/vs/{b}`, `GET /pois/{fingerprint}/occurrences`.
- Stage 6 asks the service for each POI's function occurrences and stores a compact summary in `scan_pois.similarity` (counts, up to N sample locations, links to prior review references, i.e. state of the same fingerprint elsewhere), as **metadata only**.
- Analysis reuse: stage 3 may reuse its own per-function results (extracted facts) from a previous scan when `exact_id` is unchanged, as a performance optimization, never skipping rule evaluation for a function whose ID is new in this project.

## 7. Scale notes

At 5,000 components x about 10,000 functions the live set is about 50 million rows with signatures (about 16 bytes of ID + 512 bytes of signature, or 128 permutations x 4 bytes). Partition by hash of `exact_id`; keep signatures in a compact column or a dedicated store. If Postgres proves too slow for LSH lookups at this size, move the index to a dedicated engine (spike S4 decides).

## 8. Acceptance criteria

- Reformatting, comment changes, and line shifts do not change `exact_id`.
- A changed literal or called function changes `exact_id` but keeps the fuzzy match.
- Renamed-variable copy is found through `structure_id`.
- A synthetic pair of components with known overlap reports the expected percentages in both directions.
- The service is optional: stage 6 completes without it, marking similarity `pending`.
