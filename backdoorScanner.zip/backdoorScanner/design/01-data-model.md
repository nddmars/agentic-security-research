# 01 Data Model

Author: Surya
Status: Design v1. PostgreSQL **[PROPOSED]**. DDL is a starting point for the coding agent; types and indexes are tuned in phase 1.

## 1. Principles

- Hierarchy mirrors Checkmarx: application, component, project, scan, result (POI).
- Append-only wherever history matters: profiles, lifecycle events, state history, scan results.
- CMDB data and our data are never mixed in one column. Each governed attribute has a `_cmdb` column, an `_ours` column, and a computed `_differs` flag.
- Large payloads (full evidence, profiles, reports) go to object storage; the database holds queryable fields plus a URI and a content hash.

## 2. Hierarchy and ERD

```
applications 1---* components 1---* projects 1---* scans 1---* scan_pois *---1 poi_fingerprints 1---1 poi_state_current
      |                |               |             |             |                       |
 cmdb_records     component_profiles    |        scan_files     poi_evidence         poi_state_history
 (source rows)    (versioned)           |        scan_functions
                                        |             |
                         build_commit_map        function_matches ---- component_similarity
 rule_suppressions, wf_states, wf_transitions, wf_severities, wf_versions, library_inventory (phase 2), poi_relations
```

```mermaid
erDiagram
  APPLICATIONS ||--o{ COMPONENTS : has
  COMPONENTS ||--o{ PROJECTS : has
  PROJECTS ||--o{ SCANS : has
  SCANS ||--o{ SCAN_POIS : produces
  POI_FINGERPRINTS ||--o{ SCAN_POIS : recurs_as
  POI_FINGERPRINTS ||--|| POI_STATE_CURRENT : has
  POI_FINGERPRINTS ||--o{ POI_STATE_HISTORY : logs
  COMPONENTS ||--o{ COMPONENT_PROFILES : versions
  SCANS ||--o{ SCAN_FILES : lists
  SCANS ||--o{ SCAN_FUNCTIONS : lists
  SCAN_POIS ||--o{ POI_EVIDENCE : cites
  SCANS ||--o| BUILD_COMMIT_MAP : resolves
```

## 3. Core tables

```sql
-- Source records from CMDB (raw, as received; never edited)
CREATE TABLE cmdb_records (
  cmdb_record_id BIGSERIAL PRIMARY KEY,
  entity_type TEXT NOT NULL,            -- application | component
  external_key TEXT NOT NULL,           -- CMDB id
  payload JSONB NOT NULL,
  synced_at TIMESTAMPTZ NOT NULL,
  payload_hash TEXT NOT NULL
);

CREATE TABLE applications (
  application_id UUID PRIMARY KEY,
  external_app_id TEXT UNIQUE NOT NULL,         -- business application ID
  name TEXT,
  owner_team_cmdb TEXT,      owner_team_ours TEXT,
  criticality_cmdb TEXT,     criticality_ours TEXT,
  lifecycle_cmdb TEXT,       lifecycle_ours TEXT NOT NULL DEFAULT 'active',
  differs JSONB NOT NULL DEFAULT '{}',          -- {"owner_team": true, ...} maintained by sync job
  created_at TIMESTAMPTZ, updated_at TIMESTAMPTZ
);

CREATE TABLE components (
  component_id UUID PRIMARY KEY,
  application_id UUID NOT NULL REFERENCES applications,
  external_component_id TEXT,                   -- CMDB or pipeline key, nullable if discovered
  name TEXT NOT NULL,
  type_cmdb TEXT,            type_ours TEXT NOT NULL DEFAULT 'unclassified',
  type_confidence TEXT,                         -- rule | intelligence | manual
  lifecycle_cmdb TEXT,       lifecycle_ours TEXT NOT NULL DEFAULT 'new',
  discovered_by TEXT NOT NULL,                  -- cmdb | scanner | manual
  last_build_at TIMESTAMPTZ, last_scan_at TIMESTAMPTZ,
  scan_cadence TEXT NOT NULL DEFAULT 'per_build',   -- per_build | reduced
  differs JSONB NOT NULL DEFAULT '{}'
);

CREATE TABLE component_lifecycle_events (       -- append-only
  event_id BIGSERIAL PRIMARY KEY,
  component_id UUID NOT NULL, from_state TEXT, to_state TEXT NOT NULL,
  reason TEXT NOT NULL, source TEXT NOT NULL,   -- rule | cmdb | manual
  actor TEXT, occurred_at TIMESTAMPTZ NOT NULL
);

CREATE TABLE projects (                         -- one per release line
  project_id UUID PRIMARY KEY,
  component_id UUID NOT NULL REFERENCES components,
  name TEXT NOT NULL,                           -- release line / branch / pipeline project
  pipeline_project_key TEXT,
  UNIQUE (component_id, name)
);

CREATE TABLE scans (
  scan_id UUID PRIMARY KEY,
  project_id UUID NOT NULL REFERENCES projects,
  build_id TEXT NOT NULL,
  source_url_sanitized TEXT NOT NULL,           -- credentials removed
  source_hash TEXT,                             -- SHA-256 of the archive
  tree_hash TEXT,                               -- hash over file path+hash list
  loc BIGINT, file_count INT, size_bytes BIGINT,
  started_at TIMESTAMPTZ NOT NULL, finished_at TIMESTAMPTZ,
  status TEXT NOT NULL,                         -- queued|running|partial|complete|failed
  failure_reason TEXT,
  scan_kind TEXT NOT NULL DEFAULT 'full',       -- full | reactivation
  baseline_scan_id UUID,                        -- previous complete scan of the project
  profile_version_id UUID,
  ruleset_version TEXT, tool_version TEXT, model_versions JSONB,
  coverage JSONB,                               -- per language: parsed/text_only/skipped/error counts
  report_uri TEXT,
  commit_sha TEXT, commit_status TEXT DEFAULT 'pending'   -- pending|resolved|unresolved
);

CREATE TABLE build_commit_map (                 -- filled asynchronously by the resolver
  scan_id UUID PRIMARY KEY, build_id TEXT, repo_url_sanitized TEXT,
  branch TEXT, commit_sha TEXT, resolved_at TIMESTAMPTZ,
  status TEXT NOT NULL, failure_reason TEXT, raw JSONB
);

CREATE TABLE component_profiles (               -- append-only versions
  profile_version_id UUID PRIMARY KEY,
  component_id UUID NOT NULL, version INT NOT NULL,
  scan_id UUID NOT NULL,                        -- scan that produced this version
  change_summary JSONB,                         -- diff vs previous version
  structural_fingerprint TEXT NOT NULL,         -- hash of build files + entry-point list (02)
  content_uri TEXT NOT NULL, content_hash TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL,
  UNIQUE (component_id, version)
);

CREATE TABLE scan_files (
  scan_id UUID NOT NULL, path TEXT NOT NULL,
  language TEXT, file_class TEXT,               -- source|test|generated|vendored|build|config|resource|binary|other
  sha256 TEXT, size_bytes BIGINT, loc INT,
  coverage TEXT NOT NULL,                       -- parsed|text_only|skipped|error
  coverage_reason TEXT,
  PRIMARY KEY (scan_id, path)
);

CREATE TABLE scan_functions (
  scan_id UUID NOT NULL, function_id BIGINT NOT NULL,
  path TEXT NOT NULL, name TEXT, qualified_name TEXT,
  start_line INT, end_line INT, token_count INT,
  exact_id BYTEA NOT NULL, structure_id BYTEA NOT NULL, fuzzy_sig BYTEA,
  PRIMARY KEY (scan_id, function_id)
);
CREATE INDEX ON scan_functions (exact_id);
```

## 4. POI tables

```sql
CREATE TABLE poi_fingerprints (
  fingerprint BYTEA PRIMARY KEY,                -- stable poi_id (07)
  project_id UUID NOT NULL, category TEXT NOT NULL, technique TEXT NOT NULL,
  function_exact_id BYTEA, file_path_last TEXT, function_name_last TEXT,
  first_scan_id UUID NOT NULL, last_scan_id UUID NOT NULL,
  first_seen_at TIMESTAMPTZ, last_seen_at TIMESTAMPTZ
);

CREATE TABLE scan_pois (
  scan_poi_id UUID PRIMARY KEY,
  scan_id UUID NOT NULL, fingerprint BYTEA NOT NULL REFERENCES poi_fingerprints,
  recurrence TEXT NOT NULL,                     -- new | recurrent | changed
  baseline_status TEXT NOT NULL,                -- new | unchanged | changed (removed rows live in scan_removed_pois)
  category TEXT, technique TEXT, title TEXT, description TEXT,
  file_path TEXT, start_line INT, end_line INT, function_name TEXT, language TEXT,
  origin TEXT NOT NULL,                         -- rule | ast_query | callgraph | text | intelligence
  precision_tag TEXT NOT NULL, confidence TEXT,
  priority_hint TEXT, priority_reasons JSONB,
  reachability JSONB NOT NULL,                  -- 04 / 09 shape
  trigger_details JSONB,
  similarity JSONB,                             -- exact/fuzzy matches elsewhere (metadata only)
  suppression_id UUID,
  record_uri TEXT, record_hash TEXT
);
CREATE INDEX ON scan_pois (scan_id, category);
CREATE INDEX ON scan_pois (fingerprint);

CREATE TABLE poi_evidence (
  scan_poi_id UUID NOT NULL, snippet_id TEXT NOT NULL,
  path TEXT, start_line INT, end_line INT, text_masked TEXT, role TEXT,  -- match|condition|action|route|menu|role_check|context
  text_sha256 TEXT,
  PRIMARY KEY (scan_poi_id, snippet_id)
);

CREATE TABLE poi_relations (scan_poi_id UUID, related_scan_poi_id UUID, relation TEXT);  -- fragment_of, same_behavior

CREATE TABLE scan_removed_pois (scan_id UUID, fingerprint BYTEA, last_seen_scan_id UUID);
```

State tables (`poi_state_current`, `poi_state_history`) are in 07; workflow tables (`wf_*`), `rule_suppressions` and auto-marking tables are in 17. Similarity tables (`function_lsh_bands`, `component_similarity`, `shared_functions`) are in 06. There is no allowlist table (dropped).

## 5. Lifecycle rules

Component states: `new` (first seen), `active` (builds within the activity window), `inactive` (no build within the window), `retired` (marked by CMDB and confirmed by us, or by manual action).
- **[PROPOSED]** Activity window 90 days. Inactive components keep being scanned at reduced cadence (monthly). First build after inactivity creates a `reactivation` scan, which is a full scan, and the component moves to `active`.
- Every transition writes `component_lifecycle_events` with the reason. CMDB may say retired while builds continue; our state stays `active` and the `differs` flag is set for governance.
- Application lifecycle is derived from its components (active if any component is active) and can be overridden manually, with the override recorded.

## 6. CMDB sync

Scheduled job (daily **[PROPOSED]**): pull application and component records, store raw rows in `cmdb_records`, update the `_cmdb` columns, recompute `differs`. Never write to `_ours` columns from CMDB data. A component that has builds but no CMDB record is created with `discovered_by = scanner`.

## 7. Retention

**[PROPOSED]** Scan results and POI history: retained for the life of the project (they are the triage history). Extracted source: deleted after the scan. Evidence snippets: retained with the POI (masked). Profile versions: all retained. Object-storage artifacts (CPG-like indexes, intermediate files): 30 days. Final values follow the retention decision in 13.
