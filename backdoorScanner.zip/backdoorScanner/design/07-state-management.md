# 07 POI State Management

Author: Surya
Status: Design v1.2 (2026-11-12). States, severities, transitions, suppression and cross-project marking are defined in 17 (administrator-configurable workflow). This file covers fingerprints, recurrence, tables and acceptance. Modeled on the Checkmarx carry-over idea (state survives from scan to scan per project) as a design reference only; our model is our own and does not copy Checkmarx field names.

## 1. Requirements recap

- Triage state, owner and comments survive from one scan to the next.
- State is scoped per project. Identical code in other projects is handled by similarity-based marking as proposed decisions only (17 section 5).
- History is append-only: who, when, which scan, which workflow version, what changed.
- A POI whose code changed returns to the initial state (`to_verify` in the seed workflow).
- Findings of a suppressed rule are recorded and marked, not dropped (17 section 4).

## 2. Fingerprint

```
fingerprint = SHA-256( project_id | category | technique | function_exact_id )   (128 bits kept)
```

For POIs with no enclosing function (file-level or config findings, build scripts, manifest entries, filename hits): `function_exact_id` is replaced by the hash of (normalized file path, matched snippet normalized, rule ID).

`poi_id` shown to consumers = hex(fingerprint). Because `exact_id` includes identifier names and short literals, an unchanged function always yields the same fingerprint; formatting or line moves do not break it.

## 3. Recurrence matching (stage 6)

For each candidate POI of a scan, in this order:
1. **Exact:** a fingerprint already exists for the project: `recurrence = recurrent`, state carried over.
2. **Changed code, same place:** no exact match, but the project has a fingerprint with the same category and technique in the same file path and function name (or same normalized path + enclosing class) whose function has a fuzzy match (similarity service) to the new function at or above threshold: `recurrence = changed`. A new fingerprint is created, linked to the old one (`supersedes`), and the **state resets to the initial state**, with the previous state, decision and comment shown as history context. Intentional (minimize false negatives).
3. **New:** otherwise `recurrence = new`, initial state.

Fingerprints not matched in the scan, which were `last_seen` in the previous complete scan, are written to `scan_removed_pois` (`baseline_status = removed`). Their state is left as it was; the fingerprint is marked `inactive` and reactivates as `recurrent` if the code returns.

A scan that is `partial` or `failed` never marks anything as removed.

### 3.1 Rule changes reopen review (decided)

Each reviewed POI records the `rule_id` and `logic_version` of the rule that produced it when the state was last set by a reviewer (`reviewed_rule_logic_version`). If a later scan matches the same fingerprint with a different `logic_version` of the same rule, or the POI is now produced by a different rule, the POI reopens to the initial state with history event `auto_reopen` and reason `rule_changed`, showing the previous state and comment. Cosmetic rule edits (tags, wording, priority metadata) do not change `logic_version`. Bumping `logic_version` of a broadly matching rule reopens many POIs at once, so the release process shows the expected reopen count before a bump is approved.

## 4. States and transitions

Defined by the active workflow definition (17 sections 1 to 3). Routing (decided): every new or reopened POI goes to the **MCD-Ops** group queue (`assigned_team = 'MCD-Ops'`); individual assignment is made from that queue.

Rules: the scanner and the model review module never finalize a state; they create initial-state records, attach hints, and (module) record proposed states with `actor_type = agent`. Every change requires a comment if the transition says so (seed: yes).

## 5. Tables

```sql
CREATE TABLE poi_state_current (
  fingerprint BYTEA PRIMARY KEY REFERENCES poi_fingerprints,
  state TEXT NOT NULL,                       -- key from wf_states (17)
  severity TEXT,                             -- key from wf_severities; reviewer's own, separate from scanner hint
  origin TEXT NOT NULL DEFAULT 'manual',     -- manual | auto | agent
  auto_source_fingerprint BYTEA,
  moved_into_state_by TEXT,                  -- supports require_different_actor
  assigned_to TEXT, assigned_team TEXT,
  last_comment TEXT,
  reviewed_rule_id TEXT, reviewed_rule_logic_version TEXT,
  state_version INT NOT NULL DEFAULT 1,      -- optimistic concurrency
  updated_by TEXT, updated_at TIMESTAMPTZ,
  first_detected_scan UUID, last_detected_scan UUID,
  supersedes BYTEA, active BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE poi_state_history (             -- append-only; no UPDATE/DELETE grants
  history_id BIGSERIAL PRIMARY KEY,
  fingerprint BYTEA NOT NULL,
  scan_id UUID,
  workflow_version INT,
  event_type TEXT NOT NULL,                  -- state_change | proposed | finalized | assignment | comment | severity | auto_reopen | auto_proposed | override | suppressed | unsuppressed | hint_updated | group_approved | group_rejected
  from_state TEXT, to_state TEXT,
  field_changes JSONB, comment TEXT,
  actor TEXT NOT NULL, actor_type TEXT NOT NULL,   -- human | agent | system
  occurred_at TIMESTAMPTZ NOT NULL,
  prev_hash BYTEA, row_hash BYTEA            -- hash chain for tamper evidence
);
```

Enforce append-only with database permissions (no UPDATE/DELETE on history for the application role) and the hash chain.

## 6. Concepts borrowed from Checkmarx (design reference, not a mapping task)

| Concept | Our field |
|---|---|
| Result state | `state` (workflow-defined) |
| Severity | scanner `priority_hint` and reviewer `severity` (kept separate) |
| Assigned user | `assigned_to`, `assigned_team` |
| Notes with author and time | history rows with `comment` |
| Similarity ID | `fingerprint` |
| New / Recurrent / Fixed | `recurrence`, `baseline_status` (`removed` = fixed) |
| First/last scan | `first_detected_scan`, `last_detected_scan` |
| Query name | `category`, `technique`, rule ID |

No Checkmarx result sample is needed (decided 2026-11-12).

## 7. Suppression interplay

Active rule suppressions (17 section 4) set `scan_pois.suppression_id` for matching POIs. They are recorded and counted as `suppressed`, excluded from the default queue, and do not change `state`. Lifting or expiry returns them to the queue and writes `unsuppressed` history.

## 8. Cross-project handling

Similarity occurrences are shown on each POI as before (count, locations, state of matching fingerprints elsewhere). Beyond display, decisions on identical code are proposed to other projects under the rules of 17 section 5; they are never final automatically.

## 9. Concurrency and idempotency

- State updates use `state_version` (compare-and-set); the API returns conflict on mismatch.
- Stage 6 is idempotent per scan: re-running it produces the same `scan_pois` rows and no duplicate history (unique key on `(scan_id, fingerprint)`).

## 10. Acceptance criteria

- Unchanged re-scan: all states survive; `recurrence = recurrent` for all POIs.
- Reformat-only change: fingerprints unchanged.
- One-line change inside a flagged function: POI returns as `changed` in the initial state with previous history visible.
- Raising a rule's `logic_version` reopens its previously reviewed POIs with reason `rule_changed`; a metadata-only rule edit does not.
- Removal then return of code: fingerprint reactivates with prior history linked.
- Concurrent updates by two reviewers: one wins, the other gets a conflict and no history is lost.
- History hash chain verifies end to end.
