# 12 Modules, Libraries and Build Sequence (for the coding agent)

Author: Surya
Status: Design v1.2. Python 3.12. Library names marked **(verify)** must be checked for current version, license and maintenance before adoption. Technology decisions are consolidated in 14.

## 1. Repository layout

```
backdoorscanner/
  common/              contracts (Pydantic), config, errors, logging, IDs, event types
  common_fetch/        safe URL validation, streaming download, safe extract      (shared with cxtriage)
  redaction/           secret detection and masking, masking check
  store/               SQLAlchemy models, alembic migrations, artifact store client
  intake/              pipeline trigger API, scan creation, mapping to component/project
  acquire/             stage 1 worker: fetch, extract, inventory, file classes
  profiler/            stage 2: detectors, library inventory, classification, profile versions
  detect/              stage 3: tree-sitter facts, rule engine, call graph, flow checks
  rules/               YAML rule metadata + engine rule files + fixtures (Git repository, tagged releases; 16)
  engines/             DetectionEngine interface + semgrep, opengrep, treesitter_rules adapters
  enrich/              tree-sitter hit-to-POI enrichment (function, IDs, call graph links)
  rulesrepo/           rules/presets/enablement service over Git (branch, review, tag, history)
  workflow/            configurable workflow engine, suppression, roles, severities (17)
  reviewauto/          similarity-based marking and lead review (17)
  authn/               local login, Active Directory, API tokens, API access policy
  export/              SARIF and CSV/JSON exporters
  modelreview/         phase 3 separate model review module (18)
  archive/             standalone archive script (18), not a service
  testbed/             seeded projects, open-source manifest, variants (19)
  reach/               stage 4: adapter framework, adapters/, menu matching, linking
  intel/               stage 5: tasks, context recipes, prompts, schemas, validators, gateway client
  assemble/            stage 6: merge, fingerprints, recurrence, diff, suppression, hints, reports
  similarity/          similarity service: normalization, MinHash/LSH, component similarity API
  state/               POI state machine, history, concurrency
  cmdb/                CMDB sync and difference flags
  lifecycle/           component lifecycle manager, reactivation
  commitmap/           async build ID to commit resolver
  libs/                library inventory parsers + phase 2 gateway
  api/                 poi-api (FastAPI)
  dashboard/           web UI (React + TypeScript)
  workflows/           orchestration (Temporal workflows and activities)
  evalharness/         corpus loader, runners, metrics, gates, red-team tooling
  platform/            observability, admin CLI, security helpers
  tests/               unit, fixtures, integration, security, performance
  corpus/              seeded samples + labels (separate repo recommended)
  deploy/              Containerfiles, OpenShift manifests, GitOps
```

## 2. Libraries

| Need | Library | Notes |
|---|---|---|
| Language/runtime | Python 3.12 | Pinned everywhere |
| Models/validation | `pydantic` v2, `jsonschema` | Contracts from 00 and 09; generate JSON Schema/OpenAPI |
| Config | `pydantic-settings`, `PyYAML` | Versioned YAML + env overrides |
| Web/API | `fastapi`, `uvicorn`, `httpx` | HTTP in and out |
| DB | PostgreSQL, `SQLAlchemy` 2.x (Core), `psycopg` 3, `alembic` | Bulk upserts via COPY/execute_values |
| Orchestration | `temporalio` (Python SDK) **(verify)** | Decided: Temporal |
| Object storage | `boto3` | S3-compatible |
| Parsing | `tree-sitter` Python bindings plus grammars for Java, Python, JavaScript/TypeScript, Go, C# (`tree-sitter-java`, `-python`, `-javascript`, `-typescript`, `-go`, `-c-sharp`, or a language-pack package) **(verify package choice, ABI compatibility, query predicate support such as `#match?`/`#eq?` in the binding version)** | Spike S1 |
| Text search | `ripgrep` binary (`rg --json`), invoked via `subprocess` with argument arrays | Pinned version in the image |
| Similarity | `datasketch` (MinHash/LSH) **(verify)** or own implementation; `xxhash`/`hashlib` | Spike S4 for scale |
| YARA rules (existing) | `yara-python`, or `yara-x` **(verify; APIs differ, YARA-X is not a drop-in replacement)** | Rule kind `yara` in `detect` |
| Entropy/secrets | own regex + Shannon entropy; `detect-secrets` as an optional detector source **(verify)** | Masking in `redaction` |
| XML/YAML/JSON parsing of manifests | `lxml` with `resolve_entities=False`/`defusedxml`, `tomllib` (stdlib), `PyYAML` safe_load, `orjson` | XXE-safe only; never evaluate content |
| Archive handling | stdlib `zipfile`/`tarfile` wrapped by own safe extractor | Limits and path checks |
| Fetch security | `ipaddress`, `socket`, `httpx` streaming | SSRF checks |
| LLM | provider SDKs behind own `ModelGateway` interface (Claude, Gemini) | Prompt caching, batch support |
| Retry | `tenacity` | Backoff with jitter |
| Logging/metrics | `structlog`, `prometheus-client`, `opentelemetry-sdk` | Redaction processor |
| Concurrency | `asyncio`, `concurrent.futures.ProcessPoolExecutor` | CPU-bound parsing in processes |
| Testing | `pytest`, `pytest-asyncio`, `hypothesis`, `testcontainers` | Property tests for determinism and fingerprint stability |
| Quality | `ruff`, `mypy` | CI gates |
| Metrics/stats | `numpy`, `pandas`, `statsmodels` (Wilson intervals) | Harness only |
| Front end | React + TypeScript, Vite, TanStack Table/Query, Recharts | Approved internal component kit if any |
| Packaging | `uv` or `pip-tools` with hashes; SBOM via `cyclonedx-py` **(verify)** | Pinned and scanned |

## 3. Key interfaces (sketches)

```python
class Stage(Protocol):
    name: str
    def run(self, ctx: StageContext) -> StageResult: ...      # idempotent; reads/writes artifacts by key

class Rule(BaseModel):  id; category; technique; languages; kind; query; constraints; evidence; precision; priority_hint; fixtures

class RuleEngine:
    def load(self, paths) -> list[Rule]
    def run(self, file_facts: Iterable[FileFacts], text_index: TextIndex) -> Iterator[Candidate]

class FrameworkAdapter(Protocol): ...                          # see 04

class ContextRecipe(Protocol):                                 # see 05
    def build(self, item, budget) -> ContextPack               # snippets with IDs, cut-record

class ModelGateway(Protocol):
    def complete(self, request: ModelRequest) -> ModelResponse # schema-validated JSON, usage, cache info

def function_ids(fn_tree, lang) -> FunctionIds                 # exact_id, structure_id, fuzzy_sig (06)
def fingerprint(project_id, category, technique, fn_exact_id) -> bytes   # 07
```

Determinism rules for code: no iteration over unordered sets when producing output; stable sort keys everywhere; no wall-clock or randomness in IDs; seeds fixed for MinHash.

## 4. Build sequence

0. No external inputs are needed to start. Build the test bed (19) as you go. Ask Surya only for the YARA rules, the Active Directory method and the open-source list when you reach them (13 section 5).
1. `common`, `redaction`, `store` (schema first, from 01), `common_fetch`.
2. `intake`, `acquire` with the hostile-archive tests; `workflows` skeleton running a scan through stub stages.
3. `detect`: tree-sitter fact extraction for one language (Java) end to end, the rule engine, fixtures, coverage record; then Python, Node.js, Go, .NET.
4. `rules`: category by category, with fixtures and the seeded corpus slice for that category; measure recall as rules land.
5. `similarity` normalization and IDs (needed by fingerprints), then `assemble` with fingerprints, recurrence, diff, state tables (07).
6. `profiler`, `libs` inventory parsers, component classification, `cmdb`, `lifecycle`.
7. `reach` adapters for Spring, Django/Flask/FastAPI, Express/Nest, Go routers, ASP.NET; menu matching; linking; the generic fallback hooks.
8. `intel` tasks T3 and T5 first (they enrich existing POIs), then T4, T6, T1, T2; context recipes; budgets; guardrail tests.
9. `api`, `dashboard`, reports; `commitmap` resolver.
10. `evalharness` and the gate in CI (start in step 3 and grow with each category).
11. `deploy` and hardening in parallel from step 2; load test at the end of phase 1.
12. Phase 2: `libs` gateway and the library service client; tuning of recipes from the learning loop.

## 5. Test map

| Module | Tests |
|---|---|
| common_fetch | SSRF list, traversal/symlink/bomb archives, redirect chains |
| redaction | planted secrets never appear in outputs (property test over all output paths) |
| detect/rules | per-rule positive and negative fixtures, determinism (byte-identical reruns), parse-failure handling |
| similarity | reformat/line-shift invariance, rename and fuzzy matches, percentage math on synthetic overlaps |
| assemble/state | recurrence cases in 07 section 10, idempotent stage rerun, append-only history |
| reach | per-adapter apps with ground truth; fallback test on a custom framework |
| intel | schema/citation validators, injection suite, ablation (no model = Layer 1 intact), budget exhaustion |
| workflows | kill-worker-at-each-stage resume tests |
| api | RBAC, optimistic concurrency, schema conformance |
| evalharness | metric math vs hand-computed values, gate blocks a degraded rule |
| platform/deploy | `restricted-v2` admission, default-deny network self-test, load test at 40 scans/hour |
