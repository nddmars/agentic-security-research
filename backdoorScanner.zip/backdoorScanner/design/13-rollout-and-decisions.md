# 13 Rollout, Decision Register and Spikes

Author: Surya
Status: Design v1.2 (2026-11-12), consolidated with the voice decisions. Single list of what is decided, proposed, or open.

## 1. Phases

| Phase | Goal | Exit criteria |
|---|---|---|
| 0 Spikes (2 to 4 weeks, can overlap with 1a) | Close the unknowns that change design | Spike reports S1, S2, S3, S4, S7, S9 approved; test bed started; pilot list chosen |
| 1a Foundation | Stages 1 to 3 for Java and Python; store; Temporal workflow skeleton; engine interface with Semgrep; first rules; test bed slice | Recall report for implemented categories; killed-worker test passes |
| 1b Breadth | Node.js, Go, .NET; all categories (A, E, B, F first, then D, G, C, H); profiler; fingerprints and recurrence; configurable workflow; suppression; similarity IDs | Full test bed baseline; thresholds agreed and gate on |
| 1c Reachability and UI | Adapters for main frameworks; fallback; API, authentication (local and AD), API tokens, roles administration, UI screens (15), rules in Git with presets, SARIF export | Reachability accuracy meets thresholds |
| 1d Pilot | Shadow scans on pilot applications; MCD-Ops reviews; tune hints and rules | Usefulness and noise acceptable; 40 scans/hour proven |
| 2 | Unknown libraries (11); similarity-based marking and lead review screen; build-to-commit at scale; mobile adapters; reports expansion | Phase 2 acceptance criteria |
| 3 | Model review module (separate, optional, admin switch); triage-agent integration; recipe promotion loop | Agreed with triage owners |

Pilot selection **[PROPOSED]**: 15 to 20 applications covering all five languages, a mix of component types, at least two with known incidents or red-team plants, and a few very large repositories.

## 2. Spikes

| ID | Question | Output |
|---|---|---|
| S1 | tree-sitter in Python: grammar coverage for five languages, throughput and memory on real repos (small to 12 GB), parse failure rate; run the existing YARA rules over test bed projects; Python overhead and similarity signature cost | Go/no-go; throughput numbers; bottleneck list |
| S2 | Engine comparison on the seeded test bed: Semgrep CE with its rules, Opengrep with own rules, tree-sitter rules: recall for command execution, database, file upload/download, network, exfiltration, time bombs; speed on 12 GB repos; per-language gaps; value tracking | Default engine confirmed or changed, with numbers |
| S3 | Pipeline integration: trigger payload (source zip; optionally repository details), authentication, artifact retention, build-to-commit API | Integration contract |
| S4 | Similarity at scale: MinHash/LSH in Postgres vs dedicated engine at 50M functions | Index design; thresholds |
| S5 | **Dropped.** The state model is our own design; no Checkmarx sample needed | none |
| S6 | **Closed:** Temporal chosen. Remaining check: Temporal on OpenShift approval, shared vs separate namespaces with cxtriage, SSO | Platform confirmation |
| S7 | Test bed (19): seeded apps, open-source list with licenses, label schema | Test bed v0 |
| S8 | Open source analysis sources for libraries (phase 2) | Source shortlist |
| S9 | Legal review of the Semgrep Rules License v1.0 text and adopted rule packs | Written decision; engine swap if refused |

## 3. Decision register

Status: **Decided** (by Surya), **Proposed** (default; confirm), **Open**.

| # | Question | Status | Answer |
|---|---|---|---|
| 1 | Source delivery | Decided | Trigger gives a source zip (URL) and build ID; repository details (repo, branch, commit) may be supplied instead or in addition; scanner downloads, unzips, scans; commit resolved later if not given (S3) |
| 2 | Application to owner mapping | Proposed | CMDB as input; scanner corrections on top; separate `_cmdb`/`_ours` columns (decided); interface designed now, adjusted when a sample is available |
| 3 | Scan trigger | Decided | Pipeline build (about 200 per day); reactivation scans; reduced cadence for inactive components |
| 4 | First rollout | Proposed | Pilot 15 to 20 apps; all five languages from 1b |
| 5 | Category priority | Decided | A, E, B, F first; then D, G, C, H; all in phase 1 |
| 6 | Model-assisted categories | Superseded | Scanner is rules-only; model work lives in the phase 3 module (18) |
| 7 | Test/generated/vendored code | Proposed | Scan all; lower hint (except concealment); never skip |
| 8 | Mobile | Proposed | Phase 2 |
| 9 | Binaries without source | Proposed | Listed as `skipped: binary_no_source` |
| 10 | Database-driven menus | Proposed | `unknown` with reason |
| 11 | Front-end analysis depth | Proposed | Templates and common SPA router config |
| 12 | Role normalization | Proposed | Raw plus normalized token; synonym table |
| 13 | Approved models | Proposed | Claude and Gemini via gateway; applies to the phase 3 module |
| 14 | Cost budget | Moved | Belongs to the model review module (18); configurable there |
| 15 | Second model | Proposed | Phase 3 module |
| 16 | Reviewers | Decided | All POIs to MCD-Ops queue; assignment from there |
| 17 | Hint scale and SLAs | Proposed | high/medium/low; 2/5/15 business days |
| 18 | Allowlist | Decided: dropped | Replaced by similarity-based marking (17 section 5) and suppression by rule ID in the admin panel (17 section 4) |
| 19 | Triage invocation | Proposed | Not automatic in phase 1 |
| 20 | Results access | Proposed | Postgres + object storage, UI, RBAC defined in the admin panel |
| 21 | Retention | Decided | Not a product feature; separate archive script with configurable years (18). Open: restorable archive vs permanent deletion |
| 22 | Dashboard needs | Decided | Screens in 15, Checkmarx style |
| 23 | Ticketing | Proposed | None in phase 1; export and API (CSV, JSON, SARIF) |
| 24 | Recall thresholds and sign-off | Proposed | Floor 90 percent on seeded cases for A, B, E, F; sign-off names needed |
| 25 | Corpus source | Decided | Test bed (19): agent-written seeded apps (analyst-reviewed labels) plus license-checked open-source projects |
| 26 | Red-team owner | Open | Security team member; quarterly proposed |
| 27 | Library analysis source | Open | Phase 2 (S8) |
| 28 | Library service ownership | Open | Interface in 11; owner needed |
| 29 | Hosting | Proposed | OpenShift as cxtriage |
| 30 | Shared infrastructure | Proposed | Same cluster, separate namespaces |
| 31 | Workflow | Decided | Fully administrator-configurable: states, severities, transitions, roles, whether proposer may finalize (17). Seed default provided |
| 32 | Suppression | Decided | Suppress by rule ID from the admin panel; findings recorded and marked (recording behavior proposed) |
| 33 | Authentication | Decided | Username/password or Active Directory; API tokens; admin controls who may use the API. Open: AD method and group mapping |
| 34 | Similarity marking | Decided | Identical code only, copies are proposed states, manual override wins, lead review screen |
| 35 | Rules management | Decided | Git is the single store for rules, presets and enablement; UI commits behind the scenes; second-person approval; history from Git |
| 36 | Detection engine | Decided | Semgrep (pluggable), tree-sitter post-hit, YARA, ripgrep; fallback Opengrep or own rules |
| 37 | Front end | Decided | React with TypeScript |
| 38 | Backend | Decided | Python 3.12; measure then optimize |
| 39 | Orchestration | Decided | Temporal |
| 40 | Output formats | Decided | Own JSON record plus SARIF export |
| 41 | Model use | Decided | Separate optional module, admin on/off, phase 3 |

## 4. What the coding agent starts first

See `../CODING-AGENT-BRIEF.md`. Short form: `common`, `store`, `common_fetch`/`acquire` with hostile-archive tests, Temporal skeleton, engine interface with Semgrep adapter, tree-sitter hit enrichment, similarity IDs, workflow/state engine with tests, authentication and roles, test bed seed projects.

## 5. Inputs needed from Surya

1. The existing YARA rules (or a sample): count, what they target, owner. Not blocking the first build.
2. Active Directory method (direct LDAP bind or SAML/OIDC) and group-to-role mapping.
3. Pipeline trigger payload example (source zip, optional repository details), when available.
4. CMDB export or API description, when available (interface is designed without it).
5. Owner names: threshold sign-off (AppSec lead, head of analyst team), library service owner, red-team owner.
6. Approval of the open-source list for the test bed (agent proposes).
7. Legal review of the Semgrep Rules License (S9).

Not needed anymore: sample zips, a Checkmarx result sample.

## 6. Still open (small)

1. Archive script: restorable archive vs permanent deletion after a period.
2. Which model-review tasks come first (phase 3).
3. Whether `proposed_backdoor` decisions may be copied to identical code (default off until confirmed).
4. Active Directory method and group mapping (above).
5. Final names/labels of states (data, editable in the panel).

## 7. Risks

| Risk | Mitigation |
|---|---|
| Engine misses cross-function links | Precision tags, conservative priority, recall measured on the test bed; Joern optional (S2) |
| Semgrep rules license refused | Pluggable engine; fallback to Opengrep or own rules (16) |
| Semgrep rules match only risky input | Loosened/own rule copies; recall measured per category |
| Rule noise overwhelms reviewers | Diff view, priority hints, suppression by rule with audit, similarity-based marking, feedback loop; never drop silently |
| Admin-configured workflow weakens control | Workflow changes versioned and audited; history stores workflow version; seed defaults conservative |
| Hostile code attacks the scanner | Isolation controls, hostile test suite, no execution |
| Fingerprint churn from small edits | `exact_id` plus fuzzy fallback; survival metric |
| Similarity index too large for Postgres | S4 |
| Pipeline artifacts expire before scan | Fetch immediately; `artifact_expired` reason; alert |
| CMDB inaccuracy | Own columns authoritative; difference reports |
| Auto-marking spreads a wrong decision | Copies are proposed only; reachability gate; manual override wins; lead review screen |
| Scope creep into vulnerability scanning | Out of scope (requirements 01) |
