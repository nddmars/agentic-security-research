# 10 Safety, Isolation and Evaluation

Author: Surya
Status: Design v1. Implements requirements 07 and 08.

## 1. Safety design

### 1.1 Threat model for the scanner itself
Assets at risk: the cluster, other applications' source and results, secrets, model gateway credentials. Threats: malicious archives (path traversal, symlinks, bombs), parser exploits and hangs, prompt injection through code and comments, secret leakage into prompts/logs/reports, SSRF through the build URL, tampering with rules or prompts, data theft through reports. "Hostile" means not assumed safe, including internal code.

### 1.2 Controls (baseline, always on)
| Control | Implementation |
|---|---|
| No execution of scanned code | No build, install, test or script evaluation anywhere. Static parsing only. Linted in CI: forbidden imports/calls in worker code paths that touch scanned content (`subprocess` only for `rg`, with argument arrays, fixed binary path) |
| Safe fetch | Host allowlist, SSRF defenses, size/time limits, credentials stripped (shared `common_fetch` library with cxtriage) |
| Safe extract | Traversal, symlink, bomb, nesting, file-count limits; extraction into a fresh empty ephemeral directory per scan, never into a directory containing scripts (Python run with `-I`; no interpreter started inside the workspace) |
| Pod isolation | Non-root random UID, read-only root filesystem, dropped capabilities, resource limits, one scan per pod (or per task batch), no service account token mounted for workers that do not need it |
| Network | Default-deny NetworkPolicy and EgressFirewall; `detect` and `reach` workers have no egress; `acquire` can reach only the artifact host; `intel` only the gateway |
| Parser containment | Per-file time, memory, tree-depth limits; worker process pool so a crash kills only a batch; crash recorded and file marked `error` |
| Secrets | Masking at extraction of evidence, before storage and before any prompt; masking check on every outbound prompt, log line, report and API response; live secrets reported by location and type only |
| Model layer | Structured output, citation validation, no tools, separated untrusted sections, injection indicators (05) |
| Data protection | Encryption at rest and in transit, access control on reports and evidence, retention, source deleted after the scan |
| Audit | Who ran or viewed scans/reports, model and rule versions, suppression and workflow configuration changes, state changes (07 history) |
| Scanner integrity | Rules, adapters and prompts in Git, code-reviewed, fixtures required, CI gate on corpus recall; signed release artifacts; rule changes recorded in run metadata |

### 1.3 Optional hardening (scale up where policy allows)
Separate namespaces and node pools for `acquire`/`detect` workers; sandboxed runtimes (for example gVisor or Kata) for parsing; per-scan short-lived credentials scoped to the scan's object-storage prefix; seccomp profile tightening; periodic fuzzing of the parsing path.

### 1.4 Specific design rules
- Evidence text is stored **after** masking; the unmasked match is never persisted.
- Files that look like secrets stores (key files, `.env`, keystores) are reported by path and type; their content is never put in a snippet.
- Suspicious URLs or hosts found in code are never fetched or resolved by the scanner.
- A prompt-injection attempt inside scanned code is itself recorded as a POI (05).
- Rule YAML and tree-sitter queries are treated as code: reviewed, not loaded from the scanned repository.

## 2. Evaluation

### 2.1 Primary metric and gates
Headline: **recall per category (and per technique, per language)** on planted ground truth. Precision matters for reviewer load and is reported but secondary. Release gate: no category's recall may drop below its threshold; thresholds are set after the first baseline run (**[PROPOSED]** initial floor 90 percent for categories A, B, E and F on seeded cases, adjusted per category after baseline; sign-off by the AppSec lead and the head of the analyst team, open question 24).

### 2.2 Corpus build plan (requirements 08)
1. **Seeded samples:** small apps per language (Java/Spring, Python/Flask+Django, Node/Express+Nest, Go/gin, .NET/MVC) with each catalog category and trigger family planted, labeled in a machine-readable `labels.yaml` (category, technique, file, line range, exposure: menu/hidden/role-restricted/no-entry).
2. **Technique variants:** for each seed, 5 to 10 variants (alternative APIs, split across functions/files, reflection, string assembly, encoding layers).
3. **Time-bomb set:** at least one seed per technique in 04 across languages, including computed constants and remote time sources.
4. **Benign look-alikes:** admin export, real SMTP notifier, cleanup scheduler, legitimate file upload, sanctioned reporting query.
5. **Framework coverage apps:** menu/URL/role truth for each adapter, plus custom/unknown framework apps for the fallback.
6. **Hostile content:** malformed archives, symlink tricks, huge files, odd encodings, prompt-injection files, secrets in many shapes.
7. **Real/historical cases:** sanitized internal cases and public malicious-code examples where approved (supply-chain examples included).
Generation: since an AI agent builds the system, it can also generate the seeded samples from the label schema, but every seed and variant is reviewed by an analyst (labels must be trusted). Corpus items are versioned and immutable per release, and are excluded from prompts, rule fixtures and KB entries (contamination control).

### 2.3 Harness
- `eval run --corpus <release> --ruleset <ver>` executes stages 1 to 6 on the corpus in an isolated environment and compares output to labels.
- Metrics: recall/precision per category/technique/language; reachability accuracy (URL, menu status, roles) per framework; profile accuracy (languages, frameworks, entry points); Layer 1 vs Layer 2 contribution and the false-positive rate of model-added POIs; degradation runs (parser disabled, call graph disabled); diff correctness (injected single change flagged `new`); stability (identical IDs on rerun); fingerprint survival under reformat/line shift; cost and time per application and per million LOC; coverage honesty (nothing reported clean when unanalyzed).
- Confidence intervals (Wilson) on every rate; small-sample segments flagged.
- Gates enforced in CI for rules, adapters and prompts; a failing gate blocks release.

### 2.4 Ongoing
Reviewer feedback per POI (useful, benign, duplicate) feeds priority-hint tuning and suppression suggestions. Periodic red-team: a security team member plants new behavior in a copy of a real application; the scanner must find it. Every field miss is added to the corpus with a regression test. Quarterly review of rule coverage against newly observed techniques.

## 3. Acceptance criteria

- Safety test suite (hostile archives, injection files, secret masking, SSRF) passes in CI and in the deployed environment.
- The first baseline run produces the recall report, thresholds are agreed and recorded, and the gate is enabled before any production application is scanned.
- Red-team exercise result recorded each cycle with misses added to the corpus.

## Test bed

The evaluation corpus is realized as the test bed in 19 (seeded applications plus license-checked open-source projects).
