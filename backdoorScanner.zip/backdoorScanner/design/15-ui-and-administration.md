# 15 UI Screens and Administration

Author: Surya
Status: Design v1.2 (2026-11-12). Follows the Checkmarx layout closely unless noted. Extends 09 section 7. React with TypeScript.

## 1. Sign-in and access

- Users sign in with username and password, or with Active Directory.
- The API accepts API tokens. An administrator controls which users may create or use API tokens at all (per-user API access flag, optionally per-role). Tokens: created by the user, shown once, stored as hashes, with name, expiry and revoke; every token use is audited.
- Roles and permissions are managed in the Administration section (section 4).

## 2. Screens

| # | Screen | Content |
|---|---|---|
| 1 | Portfolio / project dashboard | Applications and components by lifecycle and type, last scan age, coverage, open findings by state and severity, trend |
| 2 | Scan list | Scans per component/project with status (complete, partial), date, rule set and preset used, counts |
| 3 | Findings list | Checkmarx-style grid with column chooser and filters (category, technique, state, severity, assignee, exposure class, recurrence, baseline status, rule, language, file). Row actions: set state, set severity, assign, comment. Bulk actions |
| 4 | Finding detail | Evidence snippets (masked), reachability chain with menu path and roles, trigger details, similarity occurrences and their states elsewhere, history, auto-marking source if any |
| 5 | Scan diff | New, changed, removed between two scans; "introduced in this scan" |
| 6 | Review queue | MCD-Ops group queue; assignment to individuals from here; age against SLA; checker queue (items awaiting a second person) |
| 7 | Similarity review | For the MCD-Ops lead: decisions applied or proposed automatically (17 section 5), grouped by original decision; number of affected projects; source reviewer; one-click override; approve or reject a whole group |
| 8 | Rules management | Section 3 of 16: global, project-specific, technology switches, presets, rule history from Git |
| 9 | Reports | Export (CSV, Excel, PDF); top 10 views and other categories (top applications by open findings, top techniques, top rules, aging, reviewer throughput); saved report definitions |
| 10 | Coverage | Unparsed or skipped files by language and reason; partial scans |
| 11 | CMDB differences | `differs` flags by field; components with builds but no CMDB record; lifecycle mismatches |
| 12 | Governance | Profile changes, active suppressions and nearing expiry, reviewer throughput |
| 13 | Administration | Section 4 |
| 14 | User preferences / workspace | Section 5 |
| 15 | Phase 2 | Unknown and flagged libraries |

## 3. Filters

Checkmarx-style filter bar: add filter, combine, save as named filter, share with team, set as default. Filter definitions are stored per user (and optionally shared) in the database.

## 4. Administration section

1. **Users:** create/disable, source (local or AD), API access flag.
2. **Workflow designer:** states, severities, transitions and which roles may perform each, including whether the proposer may finalize (`require_different_actor`), whether a comment or severity is required (17). Changes are versioned and audited.
2a. **Suppress rule:** suppress a rule ID globally or per project/component with reason and optional expiry; findings stay recorded and marked `suppressed` (17 section 4).
2b. **Roles:** create, edit and delete roles. Each role is mapped to (a) screens it can see, (b) actions it can take, and (c) the state transitions it may perform. Example: analyst role may set Proposed Not Exploitable and Proposed Backdoor; reviewer or lead role may set Not Exploitable and Confirmed Backdoor. Only certain roles can confirm. Role changes are audited.
3. **Similarity marking switches:** on/off and eligible source states (17 section 5).
4. **Severity values:** configurable list, default critical, priority, high, medium, low; default selection on confirm is priority.
5. **Rules and presets:** link to rules management (16).
6. **Engine and review module switches:** detection engine selection (16); model review module on/off (18).
7. **API tokens:** list all tokens, revoke, API access policy.
8. **Audit log:** searchable, read-only.
9. **Group mappings:** AD group to role.

## 5. User preferences (workspace)

Per user: default landing screen, saved filters and default filter, column layout per grid, page size, time zone, theme. Stored in the database; changes do not affect other users.

## 6. Acceptance criteria

- Every screen action is allowed or blocked by role mapping; blocked actions are hidden or disabled and rejected by the API (not UI-only).
- A user without the API flag cannot create or use a token.
- Saved filters round-trip; export respects active filters.
- Workflow rules (including different-actor) enforced at the API according to the active definition (17).
