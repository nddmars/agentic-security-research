# 00 Main Design: POI Scanner

Author: Surya
Status: Design v1.2 (2026-11-12), consolidated with the voice decisions (14 to 19). Items marked **[PROPOSED]** are defaults to confirm (13). Everything not marked is decided.

## 1. What this is

An independent scanner that reads application source and produces **Points of Interest (POIs)**: code that looks suspicious or malicious and needs deeper review. It is not a vulnerability scanner and does not give final verdicts. The Checkmarx triage agent (cxtriage) is a separate project that may later be invoked on POIs.

## 2. Reading order

| File | Content |
|---|---|
| 00 | This file: architecture, contracts, scale, rules |
| 01 | Data model: hierarchy, ERD, DDL, lifecycle, CMDB columns |
| 02 | Stages 1 and 2: acquisition, build-to-commit, profiler, component classification |
| 03 | Stage 3: deterministic detection engine, rule format, rule library |
| 04 | Stage 4: reachability (routes, menus, roles, call-chain linking) |
| 05 | Model review module design (separate, optional, phase 3; see 18) |
| 06 | Similarity service (function IDs, component similarity) |
| 07 | Fingerprints, recurrence, state tables (workflow itself is in 17) |
| 08 | Platform: services, queue, storage, HA, hosting |
| 09 | POI output schema, API, triage handoff, dashboard and oversight |
| 10 | Safety, isolation, evaluation corpus, red team |
| 11 | Phase 2: unknown-library service interface |
| 12 | Modules, libraries (Python 3.12) and build sequence for the coding agent |
| 13 | Rollout, decision register, spikes, risks |
| 14 | Technical specification (stack, libraries) |
| 15 | UI screens and administration (roles, auth, API tokens) |
| 16 | Pluggable detection engine; rules in Git |
| 17 | Configurable workflow, severity, suppression, similarity marking |
| 18 | Model review module (phase 3) and archive script |
| 19 | Test bed |

## 3. Decisions already made

1. Scanner is independent of Checkmarx and of the triage agent. Triage may be called on POIs through a clean interface (09).
2. The scanner is deterministic and rules-based (exhaustive) and uses no model. Model work is a separate optional review module (18, phase 3, admin on/off) that only records proposed decisions or enrichments and never removes a rule-found POI.
3. Scale: about 1,000 applications, 5,000 components, at least 200 scans per day. Each stage is its own service, connected by a durable queue, with several replicas. A failed job resumes at its stage.
4. Trigger is the pipeline build. The pipeline gives a source URL (zip) and a build ID, not a commit. The commit is resolved later through the pipeline APIs by build ID, asynchronously and optionally.
5. Hierarchy: application, components, projects (one per release line), scans, POIs. Components have their own lifecycle (new, active, inactive, retired) and a type (web app, API, microservice, mobile, batch, shared library, others, plus unclassified).
6. Profiles are built once and updated incrementally as new versions, never overwritten.
7. CMDB is an input, not truth. Our record is always the latest. CMDB values and our values live in separate columns for governance reporting.
8. Similarity is computed per function from normalized content (identifier names and structure, never line numbers), with an exact score and a fuzzy score. A separate similarity service reports component-level similarity in both directions and the shared functions.
9. POI state is modeled on Checkmarx: stable fingerprint, current-state record, append-only history, new/recurrent flag, scoped per project. Identical code in other projects gets the decision as a proposed state for review; near-matches are suggestions; manual override wins (17 section 5).
10. Languages: Java, Python, Node.js, Go, .NET first. Mobile later.
11. Phase 2: unknown libraries are detected and handed to a separate analysis service (11).
12. Python 3.12.
13. Models (phase 3 module only): Claude and Gemini behind a gateway, with secret masking. **[PROPOSED]** Same gateway as cxtriage.
14. Reviewers: every POI is routed to the **MCD-Ops** group queue; assignment to individuals happens from there.
15. A POI is reopened to review when its code changes or when the rule that produced it changes (07).
16. Existing YARA rules are a supported rule source for text-level detection (03 section 4.1).
17. Detection engine is pluggable: Semgrep default (internal use, Legal to confirm), Opengrep or own tree-sitter rules as fallback; tree-sitter does post-hit work (16).
18. Rules, presets and enablement live in Git; UI commits behind the scenes with second-person approval (16).
19. The workflow (states, severities, transitions, roles) is fully administrator-configurable; there is no allowlist; rules can be suppressed by rule ID from the admin panel, with findings recorded and marked (17).
20. Orchestration: Temporal. Backend Python 3.12. Front end React with TypeScript. Login by username/password or Active Directory; API tokens controlled by the administrator (14, 15).
21. Output: own JSON record plus SARIF export (09).
22. Retention is an external archive script, not a product feature (18).

## 4. Pipeline (six stages)

```
 pipeline build
      |  (source zip URL + build ID; optionally repository details)
      v
[1 Acquire] -> [2 Profile] -> [3 Detect] -> [4 Reachability] -> [6 Assemble] -> POI store -> API -> UI, SARIF, triage
   zip fetch     languages      engine hits    routes, menus       merge, IDs,
   safe unzip    frameworks     + tree-sitter  roles, call-        recurrence, diff,
   hash          entry points   enrichment     chain linking       suppression,
                 libraries      over every     per POI             coverage report,
                 component      file                               append-only store
                 type
      ^                                                                  |
      |                                                                  v
 CMDB sync, build->commit resolver (async)          [5 Model review module: optional, separate, phase 3;
                                                    reads stored results, records proposed items]
                                       Similarity service (async, fed by stage 3 function IDs)
```

Stage 5 is detached: stage 6 never waits for it and the scan is complete without it.

Stage contracts: each stage reads its input from object storage plus the database, writes its output as versioned artifacts, and emits a completion event on the queue. Re-running a stage with the same inputs and versions produces the same output (determinism requirement for stages 1 to 4 and 6).

## 5. Cross-cutting contracts

**IDs**
- `application_id`, `component_id`, `project_id`, `scan_id`: UUID, plus the external business keys (application ID from CMDB, pipeline project name).
- `function exact_id`: hash of the normalized function (06).
- `poi_fingerprint` (the stable `poi_id` seen by consumers): hash of project, category, technique and function exact_id (07).
- `scan_poi_id`: one occurrence of a fingerprint in one scan.
- `snippet_id`: per POI, `S1`, `S2`, and so on; every model claim cites these.

**Precision tags** (carried by every fact and POI): `full_analysis` (AST plus resolved link), `ast_local` (AST match within one function), `name_based` (search or name match), `text_only` (regex or text match), `intelligence` (model-derived, cited).

**Entry types:** `web_route`, `api_endpoint`, `scheduled_job`, `message_listener`, `cli_command`, `startup_hook`, `library_internal`, `unreachable`, `unknown`.

**Coverage levels per file:** `parsed`, `text_only` (grammar missing or parse failed), `skipped_with_reason` (size, binary, limit), `error`. Nothing is dropped silently, and the coverage report states what was not analyzed.

## 6. Capacity assumptions

- 200 scans a day is about 8 an hour on average. **[PROPOSED]** Plan for peaks of 5 times average (about 40 an hour, bursts at release time) and for a backlog of one day after an outage.
- 5,000 components with 10,000 functions each on average would be 50 million function records live, so the similarity service uses banded LSH tables, not pairwise comparison (06).
- Repository size runs from 100 KB to 12 GB. Stage 1 streams and limits, stage 3 works per file with time and memory limits, and heavy repositories get dedicated worker classes (08).

## 7. Non-negotiable rules

1. Never execute scanned code (no build, install, test, script evaluation).
2. Scanned content is data, never instructions to a model.
3. Mask secrets before any model call and before storing snippets. Report live secrets by location and type only.
4. Never report "clean" for something not analyzed. Coverage gaps are first-class output.
5. The model never removes or downgrades away a rule-found POI.
6. Stored results are append-only and versioned.
7. Rule, adapter and prompt changes go through review and the evaluation gate (10).

## 8. Phases

| Phase | Content |
|---|---|
| 0 | Spikes (13): engine comparison, tree-sitter coverage, pipeline contract, similarity scale, test bed, Legal review of Semgrep rules |
| 1 | Stages 1 to 4 and 6 for Java, Python, Node.js, Go, .NET; all POI categories at rule level (A, E, B, F first); reachability adapters; configurable workflow and suppression; fingerprints and recurrence; similarity IDs; baseline and diff; API, authentication, roles, UI, rules in Git, SARIF; test bed |
| 2 | Unknown-library detection (11); similarity-based marking with the lead review screen; build-to-commit at scale; mobile adapters; report expansion |
| 3 | Model review module (separate, optional); triage-agent integration; recipe promotion loop |

## 9. Definition of done for phase 1

- Every category in the POI catalog has rules with fixtures, and recall per category is measured on the corpus and signed off (10).
- A scan of any pilot application produces a POI set, coverage report and application profile, with reachability facts on every POI.
- A single injected change is flagged `new` in the next scan; triage state survives an unchanged re-scan.
- 200 scans a day sustained on the target platform, with a worker killed mid-scan and the scan resuming at its stage.
- Safety tests pass (hostile archives, prompt-injection files, secrets masking).
- Workflow administration, suppression by rule, authentication with roles and SARIF export work end to end.
