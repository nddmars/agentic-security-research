# 02 Stages 1 and 2: Acquisition and Profiler

Author: Surya
Status: Design v1.2 (2026-11-12). Trigger input is a source zip URL plus build ID; the pipeline may also send repository details (repo, branch, commit), in which case the commit is known immediately and the async resolver is skipped.

## 1. Stage 1: Acquisition

**Trigger:** the pipeline build calls the scanner API (or publishes an event) with `build_id`, `source_url`, and the identifiers it knows (pipeline project key, application ID if available). **[PROPOSED]** A webhook plus a polling safety net, so a missed call does not lose a build.

**Steps**
1. Validate the request; map to application, component and project (create the component and project if unknown, marked `discovered_by = scanner`). Create `scans` row, status `queued`.
2. Validate the URL: host allowlist, no IP literals, no `file://`, DNS re-check against private ranges, redirect-chain check, credentials stripped before storage.
3. Download as a stream with size and time limits, computing SHA-256 while streaming. Failures: `host_not_allowed`, `auth_failed`, `artifact_expired`, `fetch_timeout`, `size_limit_exceeded`.
4. Safe extraction: no path traversal, no symlinks leaving the root, bomb limits (compression ratio, total size, file count, nesting depth), skip special files. Failure reason `archive_unsafe`.
5. Build the file inventory: path, size, SHA-256, language (extension plus shebang plus content sniff), file class (below), line count. Compute `tree_hash` over the sorted path+hash list.
6. Duplicate check: the same `source_hash` as a previous complete scan of the project means identical source. **[PROPOSED]** Record the new scan as a reference to the earlier result (no repeat analysis) unless the ruleset or tool version changed.
7. Write the extracted workspace to scratch (ephemeral volume) and the inventory to object storage. Emit `SourceReady`.

Reuse the safe-fetch and safe-extract implementation from cxtriage (`02-source-acquisition.md`, sections 6 and 7) as a shared library rather than rewriting it. **[PROPOSED]** Package it as `common_fetch`, consumed by both projects.

**File classes** (path and header rules, no parsing): `source`, `test`, `generated`, `vendored`, `build` (output folders, compiled files), `config`, `resource`, `binary`, `other`. Requirement open question 7 default **[PROPOSED]**: scan every class; test, generated, vendored and build files get a lower priority hint but are never skipped, because attackers hide code there. Binaries and compiled artifacts without source are listed with coverage `skipped` and reason `binary_no_source`, and a coverage-gap line appears in the report.

**Large repositories (up to 12 GB):** stream extraction to scratch; exclude only by explicit configured rules (for example `node_modules` contents are inventoried, hashed, and passed to stage 2 as library evidence but not parsed in stage 3 unless the path is `vendored_modified`, i.e. the hash differs from the registry hash, which needs phase 2). Excluded content is recorded as `skipped` with reason, never dropped silently. Per-scan limits are configuration; exceeding them yields `partial` status and a coverage report that says what was not covered.

**Build-to-commit resolver (asynchronous, optional)**
- After `SourceReady`, a separate job calls the pipeline API with `build_id` to get repository URL, branch and commit. It writes `build_commit_map` and fills `scans.commit_sha`.
- A scan never waits for it. Failure leaves `commit_status = unresolved`. Retry with backoff for a day. **[PROPOSED]**
- Open input from the user: which pipeline API(s) exist, whether history is retained for old builds, and what it returns (13, spike S3).
- Phase 2 can use the commit for history, blame and the diff between commits (the cxtriage phase-2 file has the Git history design).

## 2. Stage 2: Profiler

Goal: build the **component profile** (requirements 05) as a versioned record, cheaply, with reuse across scans.

**2.1 Structural fingerprint and reuse.** Compute `structural_fingerprint` = hash of (sorted contents of build and dependency manifests, the entry-point candidate file list, the framework config files). If it equals the latest profile version's fingerprint, reuse that profile for the new scan (record `profile_version_id`, no new version). If it differs, rebuild only the affected sections and save a new version with `change_summary` (new endpoint, new dependency, new outbound client, new language). Reactivation scans always rebuild fully.

**2.2 Detectors** (deterministic, from file inventory and manifests):

| Signal | Detects |
|---|---|
| `pom.xml`, `build.gradle(.kts)`, `*.jar` manifests, `web.xml` | Java; Spring Boot / Spring MVC (starter artifacts), JAX-RS, servlets, Struts (`struts.xml`) |
| `requirements*.txt`, `pyproject.toml`, `Pipfile`, `setup.py` | Python; Django, Flask, FastAPI, Celery |
| `package.json`, lock files | Node.js; Express, NestJS (`@nestjs/*`), Next, React/Angular/Vue front ends |
| `go.mod`, `go.sum` | Go; net/http, gin, echo, chi |
| `*.csproj`, `*.sln`, `packages.config`, `appsettings*.json` | .NET; ASP.NET MVC, Razor Pages, Web API, Blazor, minimal APIs |
| `AndroidManifest.xml`, `*.xcodeproj`, `Package.swift`, `build.gradle` with android plugin | Mobile (flagged, adapters later) |
| `Dockerfile`, `docker-compose*.yml`, Helm charts, `Jenkinsfile`, CI YAML | Deployment shape, build scripts (also supply-chain POI sources) |
| Config files by name | Auth mechanism (Spring Security config, Django `AUTHENTICATION_BACKENDS`, passport/JWT middleware, `[Authorize]` usage) |

Each detection records evidence (file and line) and a confidence. Frameworks and versions come from dependency declarations, never from trusting a README.

**2.3 Entry-point inventory.** Delegated to the reachability adapters in "inventory mode" (04): routes, jobs, listeners, CLI commands, startup hooks. In stage 2 it is a coarse count by type with file locations, used to decide which adapters run and to detect profile change. The full route and menu extraction happens in stage 4.

**2.4 Dangerous-capability inventory.** A cheap ripgrep/AST pass over capability APIs (process, file, network, database, email) producing counts and locations per file. This both fills the profile and primes stage 3.

**2.5 Library inventory.** Parse manifests and lock files into (name, version, ecosystem, source registry or URL, hash). Stored in the profile; used in phase 2.

**2.6 Unknown stacks.** If detectors find no framework for a significant share of source files, or an entry-point type with zero adapters, the profile gets `unknown_stack` entries and stage 5 (task T1 in 05) proposes the framework and where routes and menus live, citing files.

**2.7 Component classification** (writes `components.type_ours`, with `type_confidence`):

| Type | Rule signals |
|---|---|
| web app | server-side templates or a front-end bundle plus routes; menu sources found |
| API | routes/controllers with no templates or front end |
| microservice | API plus container image definition, messaging client or service-discovery config, small bounded surface |
| mobile | Android/iOS project files |
| batch | scheduler or main entry with no routes |
| shared library | no entry points; packaged as a library (`<packaging>jar</packaging>` without a main class, `setup.py` library, package with no `main`) |
| other | defined in config; `unclassified` when signals conflict or are absent |

Classification never blocks a scan. A change in type is recorded as a profile change and a lifecycle event, and CMDB's value stays in `type_cmdb`.

## 3. Lifecycle updates

Stage 6 calls the lifecycle manager: updates `last_build_at`, applies the activity window rules (01 section 5), schedules reactivation scans, and runs a daily job that moves components to `inactive` and applies `scan_cadence = reduced`.

## 4. Failure handling

| Failure | Behavior |
|---|---|
| Fetch/extract fails | Scan `failed` with reason; retried per policy; alert if repeated for a component |
| Partial extraction (limits) | Scan continues as `partial`; coverage report lists gaps |
| Profiler cannot detect anything | Profile with `unknown_stack`; stages 3 and 4 run generic rules and the fallback; intelligence task T1 runs |
| Resolver fails | `commit_status = unresolved`; scan unaffected |

## 5. Acceptance criteria

- Hostile archive suite is rejected safely (traversal, symlink, bomb, nested).
- Profile detection accuracy on the corpus (languages, frameworks, entry-point counts) meets the thresholds set in phase 0.
- Re-scan of an unchanged component reuses the profile (no new version); a one-line manifest change produces a new version with a correct `change_summary`.
- CMDB sync never changes `_ours` columns, and `differs` flags are correct on a seeded conflict set.
