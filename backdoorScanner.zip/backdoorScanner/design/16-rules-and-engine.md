# 16 Detection Engine (Pluggable) and Rules Management

Author: Surya
Status: Design v1.2 (2026-11-12). Decided by Surya in the voice sessions. Supersedes the old engine choice in earlier drafts of 03.

## 1. Engine decision

Reasoning: calls that matter (database access, command execution, file upload and download, network calls) depend on language and framework, with hundreds of variants. Tree-sitter only parses; it has no knowledge of which calls matter. A rule library supplies that knowledge, so the project relies on an existing rule engine and library instead of writing the whole catalog by hand.

- **Default:** Semgrep engine (CE, LGPL 2.1) with its ready-made rules as the starting library, used internally. Rules are mapped to POI categories and tagged by us.
- **Pluggable:** the engine sits behind the `DetectionEngine` interface (14 section 2). If Legal objects to the Semgrep rules license, switch to Opengrep (LGPL fork, no rules of its own) with our own rules, or to tree-sitter queries with our own rules, without changing the rest of the pipeline.
- **Own rules on top:** Semgrep rules target vulnerabilities and often match only when the input looks risky. We want every command execution, whether or not exploitable. Some rules are loosened by our copies; some are written fresh; hidden-functionality and time-bomb rules are our own.
- **YARA** rules stay a supported rule source (03 section 4.1). **ripgrep** stays for config files and strings.
- **tree-sitter** handles what an engine cannot: for each hit, parse the file once, find the enclosing function, produce function IDs for similarity, the call graph, and route and menu links. Hits in config or scripts without a function remain file-level POIs.

Licensing note (researched): Semgrep engine LGPL 2.1. Semgrep-maintained rules moved in December 2024 to the Semgrep Rules License v1.0: not open source, internal business use allowed, vendors barred from using the rules in competing products or SaaS. Third-party registry rules keep their own licenses. Read only Semgrep's own documentation, not the license text: Legal must confirm. Semgrep may change terms again, so keep own-rule fallback current.

## 2. Spike changes

- **S2 (revised):** run Semgrep (with its rules), Opengrep (with our rules) and tree-sitter rules on the seed corpus; measure recall for command execution, database access, file upload/download, network, exfiltration and time-bomb categories A, B, E, F first; measure speed on 12 GB repositories; per-language gaps; how well each tracks values across functions. Output: engine default confirmed or changed, with numbers.
- **S1 (addition):** measure Python orchestration overhead and similarity signature cost; identify bottlenecks.
- **New S9:** Legal review of the Semgrep Rules License v1.0 text and any rule packs adopted.

## 3. Rules management

### 3.1 Scopes
- **Global rules:** apply to all projects.
- **Project-specific rules:** apply to selected projects or components.
- **Technology switches:** enable or disable by technology (Java, Python, Node.js, Go, .NET, others).
- **Presets:** named bundles of rules (like a Checkmarx preset). A project or component selects a preset; a default preset exists.
- **Rule history:** from Git history (commit log per rule file), not from a database table.

### 3.2 Git as the single store
Rule content, presets and enablement settings (which rules and technologies are on, preset per project, project-specific selections) are files in a rules repository. No rules table is kept.

- The UI edits a rule or setting; the service writes it as a commit on a branch.
- A second person approves before merge to main (second-person approval; the approval rule is configurable like the workflow in 17).
- Merge requires the rule's test fixtures to pass (positive and negative) and the expected reopen count to be shown when a rule's `logic_version` changes (07 section 3.1).
- Commits record who and why.
- Scanners load rules only from tagged releases, so a half-finished edit never changes a live scan.
- The rule history screen reads the commit log and shows diffs between versions.
- Scan records store the rules release tag and preset used.

### 3.3 Repository layout (proposed)
```
rules-repo/
  engines/semgrep/...   engines/opengrep/...   engines/treesitter/...   yara/...
  metadata/             # rule id, category, technique, logic_version, priority_hint, precision
  presets/<name>.yaml
  enablement/global.yaml, technologies.yaml, projects/<project>.yaml
  fixtures/             # positive and negative samples per rule
```

### 3.4 Acceptance criteria
- A rule edit from the UI becomes a commit on a branch; it cannot reach main without a second approver and passing fixtures.
- A scan only uses a tagged release; the tag is stored on the scan.
- Switching the engine in configuration changes no downstream contracts (`RawHit` stays identical).
- Rule history screen matches `git log` for the rule file.
