# 14 Technical Specification

Author: Surya
Status: Design v1.2 (2026-11-12). Captures the technology decisions from the 2026-11-12 voice sessions. Library names marked **(verify)** need a check of current version, license and maintenance before adoption.

## 1. Decisions at a glance

| Area | Decision |
|---|---|
| Backend language | Python 3.12 for all services. Measure in spike S1; move only a proven bottleneck (for example tree walking, MinHash signatures) to Go or Rust. Heavy work is already native (Semgrep engine, ripgrep, YARA, tree-sitter), so Python orchestrates |
| Front end | React with TypeScript (same stack as the proposal in 12). TypeScript types are generated from the published OpenAPI schema |
| Detection engine | Pluggable. Default: Semgrep engine and rules (internal use, Legal to confirm). Fallbacks: Opengrep with own rules, or tree-sitter queries with own rules. See 16 |
| Post-hit analysis | tree-sitter: enclosing function, function IDs, call graph, route and menu links |
| Signatures | Existing YARA rules (regex, POI regex, filename regex) stay |
| Text search | ripgrep |
| Rules, presets, enablement | Git is the single store. UI commits behind the scenes with approval. See 16 |
| Authentication | Username and password, or Active Directory. API tokens. Admin controls who may use the API. See 15 |
| States | Administrator-configurable workflow; seed: To Verify, Proposed Not Exploitable, Not Exploitable, Proposed Backdoor, Confirmed Backdoor. Severity is a separate configurable column. See 17 |
| Model use | Not part of the scanner. Separate optional review module, admin on/off, phase 3. See 18 |
| Retention | Not a product feature. Separate archive script. See 18 |
| Orchestration | Temporal (decided) |
| Workflow | Fully administrator-configurable states, severities, transitions, roles; no allowlist; suppression by rule ID (17) |
| Output | Own JSON record plus SARIF 2.1.0 export (09) |
| Test bed | Seeded applications plus license-checked open-source projects (19) |

## 2. Runtime architecture additions

- `engines/` adapter layer: `DetectionEngine` interface with implementations `semgrep`, `opengrep`, `treesitter_rules`. All produce the same `RawHit` record (rule id, file, line range, engine, rule metadata). The rest of the pipeline never sees engine-specific output.
- `enrich/hit_to_poi`: for each `RawHit` in a source file, tree-sitter parses the file once, finds the node at the hit line, walks up to the enclosing function, and emits function name, line range, `exact_id`, `structure_id`, `fuzzy_sig`, calls, annotations (route path, role checks). Hits in config or script files without a function stay file-level POIs.
- `rulesrepo/`: reads a tagged release of the rules Git repository; also the service behind the rules UI (branch, commit, review, merge, tag).
- `reviewauto/`: similarity-based proposal of decisions to identical code (17).
- `authn/`: local login, AD integration, API token issue and revoke, API access policy.
- `archive/`: standalone script, not part of the services (18).
- `modelreview/`: optional separate module (18), phase 3.

## 3. Libraries (additions and changes to 12 section 2)

| Need | Library | Notes |
|---|---|---|
| Detection engine (default) | `semgrep` CLI (Semgrep CE engine, LGPL 2.1) invoked as a subprocess with JSON output **(verify version)** | Rules under Semgrep Rules License v1.0 are internal business use only; Legal confirms before production |
| Detection engine (fallback) | Opengrep CLI **(verify release stability, large repo behavior)**, or tree-sitter queries via `tree-sitter` bindings | Same rule metadata contract |
| Parsing | `tree-sitter` plus grammars (Java, Python, JavaScript/TypeScript, Go, C#) | As in 12 |
| Signatures | `yara-python` (or `yara-x`, not a drop-in replacement) | Existing rules |
| Text search | `ripgrep` | Argument arrays only |
| Git access for rules | `GitPython` or `pygit2` **(verify)**, or the `git` CLI with argument arrays | Branch, commit, merge, tag, log |
| Authentication | `python-ldap` or `ldap3` for Active Directory **(verify)**; OIDC/SAML library if the company uses SSO **(verify)**; `argon2-cffi` for local password hashes; `PyJWT` for session tokens | API tokens stored as hashes, shown once |
| API | `fastapi`, `uvicorn`, `pydantic` v2 | OpenAPI generated; TS types via `openapi-typescript` **(verify)** |
| Front end | React, TypeScript, Vite, TanStack Table and Query, Recharts, a form library (React Hook Form) **(verify)** | Table-heavy, saved filters, exports |
| Export | `openpyxl` (Excel), `csv`, `reportlab` or HTML to PDF **(verify)** | Reports screen |
| Everything else | As in 12 section 2 | |

## 4. Phases (updated)

| Phase | Content |
|---|---|
| 1 | Scanner core: acquire, profile, detect (engine plus tree-sitter), reachability, assemble; configurable workflow with severity; rules in Git with presets and enablement; UI core screens; roles administration; authentication and API tokens |
| 2 | Unknown libraries (11); similarity-based auto-marking and the lead review screen; build-to-commit at scale; mobile adapters; reports expansion |
| 3 | Model review module (optional, separate); triage-agent integration; recipe promotion loop |

Phase 1 and 2 focus on a solid scanner with no model dependency.

## 5. Performance stance

Python everywhere first. Spike S1 measures: Semgrep and tree-sitter throughput on 12 GB repositories, similarity signature cost at millions of functions, API latency. A measured hot spot is rewritten as a native extension or Go/Rust worker behind the same interface.

## 6. Open technical items

- Temporal on OpenShift approval and namespace layout (S6 remainder).
- Opengrep large-repo behavior and release stability (S2).
- Semgrep rules license: Legal confirmation. Fallback is own rules, so the pipeline does not depend on it.
- AD integration method (LDAP bind or SAML/OIDC) and group-to-role mapping: needs input.
