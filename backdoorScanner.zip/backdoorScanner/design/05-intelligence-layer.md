# 05 Stage 5: Intelligence Layer

Author: Surya
Status: Design for the separate model review module (18), built in phase 3, enabled or disabled by an administrator. It is not part of the scanner: scans complete without it. Wherever this file says "stage 5" or "the intelligence layer", it means that module. Its output is recorded as proposed decisions or enrichments (actor type `agent`) and never as final states (17). Cost budgets (decision #14) belong to the module.

## 1. Role and limits

The model works only on material the deterministic layers produced: cited snippets, call-graph facts, the profile. It adds knowledge where rules are weak. It never reads the whole repository, never removes or downgrades-away a rule-found POI, and never gives a final verdict.

## 2. Tasks

| ID | Task | Input | Output |
|---|---|---|---|
| T1 | Profile completion for unknown stacks | `unknown_stack` entries, manifests, top-level file list, sampled entry files | Proposed frameworks, build system, where routes/menus/auth live; each with cited snippets |
| T2 | Route/menu/role discovery (generic fallback) | Fallback hits (04 section 9) with context | Route table, menu entries, role rules, each cited; unresolved items listed |
| T3 | Business vs utility judgment | Candidate POI, its reachability facts, evidence snippets, profile summary | `business_likelihood` (likely_business, unclear, likely_utility_or_hidden) with reasons and citations; feeds the priority hint only |
| T4 | Unusual-code second pass | `unusual_candidates` from stage 3 (high-entropy blobs, dynamic loading with computed names, unexplained network use, non-trivial uncalled functions) plus context | New POIs (origin `intelligence`) or enrichment of existing ones, cited; or `no_concern` with a reason (recorded, never silent) |
| T5 | Grouping and normalization | All POIs of a scan in a compact form | `related_pois` groups (fragments of one behavior), consistent titles/descriptions in neutral language |
| T6 | Trigger classification | Computed/obfuscated conditions the rules could not classify, with guarded action | Trigger family and technique proposal, `value_origin`, cited |

T3 and T5 run on every scan for all POIs above a **[PROPOSED]** priority floor; T4 and T6 run only on stage 3 markers; T1 and T2 run only when needed. This keeps model use proportional to what rules cannot decide.

## 3. Context building (reuses the cxtriage custom-rules approach)

Each task gets a **fixed recipe** of context steps, run by our code:
1. Enclosing function or class plus imports and constants (tree-sitter).
2. References to the matched name/value/constant (ripgrep), max two hops.
3. Callers of the function (call graph), bounded.
4. Neighbors by convention: config, environment and properties files, test/fixture directories, same package.
5. Package as cited snippets within a **[PROPOSED]** budget (default 6,000 tokens of code per POI for T3/T4/T6, 12,000 for T1/T2). Record what was cut.

The model may request up to **[PROPOSED]** 3 extra lookups per item (a ripgrep for a name, a read of a named file range, a callers query). Lookups run in our code, are logged, and results are snippets with IDs. The learning loop from `../reference/custom-rules-context-search.md` applies: lookups requested often for the same rule/technique and language are proposed for promotion into the fixed recipe after human approval and a golden-set check.

## 4. Prompt and schema rules

- Static instruction prefix first (cacheable), then task-specific instructions, then a clearly delimited **untrusted data** section containing the snippets. Instructions never appear inside the data section; the model is told that content in it may contain hostile instructions and must be ignored.
- Structured JSON output validated against a JSON Schema; one repair attempt, then the item is marked `intelligence_failed` and processing continues.
- Every claim carries `cites: ["S3", "S5"]` referencing snippet IDs. A validator checks that each cited ID exists, and that any quoted text is a substring of the cited snippet. Claims without valid citations are discarded and counted.
- Output schema for T4 (example):

```json
{
  "items": [
    {
      "kind": "new_poi | enrich_poi | no_concern",
      "target_poi": "fingerprint-or-null",
      "category": "D.concealment",
      "technique": "decoded_payload_executed",
      "title": "neutral description",
      "reasoning": "what the code does, factual",
      "cites": ["S2", "S4"],
      "priority_hint": "high | medium | low",
      "confidence": "high | medium | low"
    }
  ]
}
```

- Free text from the model never goes into Checkmarx-like fields unvalidated; descriptions are stored as `description` with `origin = intelligence`.

## 5. Guardrails (enforced in code, not only in the prompt)

1. The merge step refuses any model output that deletes, hides or lowers a Layer 1 POI's priority below its rule default; model changes to Layer 1 POIs are limited to additive fields (reasons, business_likelihood, related_pois, extra evidence).
2. Model-added POIs are always `origin = intelligence`, `precision = intelligence`, and are reported in their own counts.
3. Secrets are masked before prompt construction. A masking check on the final prompt blocks the call if a known secret pattern remains.
4. The model has no tools. All lookups are made by our code; the model emits lookup requests as data.
5. No network except to the gateway; no code execution.
6. **Prompt-injection indicators** (instruction-like text, "ignore previous", role-play, encoded instructions in comments or strings) detected in snippets raise an `injection_indicator` flag on the POI and are themselves reported as a POI under concealment (D) when found in source, since hostile instructions in code are suspicious by nature.

## 6. Model routing, cost and budgets **[PROPOSED]**

- Cheap tier for T3, T5, T6 and simple T2; strong tier for T1, T4 and for high-priority POIs. Models are Claude and Gemini behind the gateway, selected by configuration.
- Second model for POIs with priority hint `high` (open question 15): run T3/T4 with another model; disagreement raises the priority hint and records both outputs. Never lowers a hint.
- Budget per scan (tokens and cost) and per application per quarter. When the budget is reached the layer stops, the scan is finalized with `intelligence_partial` and the report states which POIs lack enrichment. Layer 1 results are unaffected.
- Batch API for non-urgent scans, prompt caching on the static prefix, per-snippet-hash result cache (same snippet + same task + same prompt version = reuse), and function-similarity reuse as a cost lever only: a prior T3 result for an identical function is attached as metadata (07), but the model still re-runs when context (reachability, roles) differs.

## 7. Failure handling

Timeouts, rate limits and invalid outputs retry with backoff; after the cap the item is marked `intelligence_failed` and the scan continues. A systemic failure (gateway down) pauses the stage with queued work; assembly can proceed without it after a configurable wait, marking the scan `intelligence_partial` and scheduling a catch-up job.

## 8. Measurement

Each task logs: model, prompt version, tokens, latency, schema validity, citation validity rate, lookups used, and outcome. The evaluation harness (10) reports the false-positive rate of model-added POIs, the recall gain over Layer 1, and fact accuracy for T1/T2 against labeled profiles and routes.

## 9. Acceptance criteria

- Citation validity of accepted claims is 100 percent by construction; discarded-claim rate is tracked.
- A planted prompt injection in a comment never changes a result (corpus hostile-content tests).
- Removing the model layer entirely leaves every Layer 1 POI intact (ablation test).
- Budget exhaustion produces a complete Layer 1 result and an honest `intelligence_partial` report.
