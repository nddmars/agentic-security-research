# 11 Phase 2: Unknown Libraries and the Library Analysis Service Interface

Author: Surya
Status: Phase 2 design. Phase 1 must produce the library inventory and leave the hooks described here. The library analysis service itself is a separate project with its own owner.

## 1. Phase 1 groundwork (already in scope)

- The profiler (02) writes a complete library inventory per component: `name`, `version`, `ecosystem`, `registry_or_source`, `hash` (when in lock files), `scope` (runtime, build, test), `declared_in` (file and line), `kind` (`registry`, `internal`, `vendored`, `git`, `url`, `local_path`).
- Supply-chain rules (03) already flag unusual sources: git references, raw URLs, local paths, non-standard registries.
- Database tables are created in phase 1 (empty): `libraries` and `component_libraries`.

```sql
CREATE TABLE libraries (
  library_id UUID PRIMARY KEY, ecosystem TEXT NOT NULL, name TEXT NOT NULL, version TEXT NOT NULL,
  hash TEXT, source_kind TEXT, source_ref TEXT,
  known_status TEXT NOT NULL DEFAULT 'unchecked',   -- unchecked | known | unknown | flagged | analysis_pending | error
  lookup_source TEXT, looked_up_at TIMESTAMPTZ,
  analysis_status TEXT, analysis_verdict TEXT, analysis_evidence_ref TEXT, analyzed_at TIMESTAMPTZ,
  UNIQUE (ecosystem, name, version, hash)
);
CREATE TABLE component_libraries (
  component_id UUID, profile_version_id UUID, library_id UUID,
  scope TEXT, declared_in TEXT, line INT,
  PRIMARY KEY (profile_version_id, library_id)
);
```

## 2. Inventory parsing per ecosystem (phase 1 deliverable, phase 2 consumer)

| Ecosystem | Files |
|---|---|
| Maven/Gradle | `pom.xml` (incl. parent and dependencyManagement), `build.gradle(.kts)`, `gradle.lockfile`, vendored `*.jar` (manifest and hash) |
| PyPI | `requirements*.txt`, `poetry.lock`, `Pipfile.lock`, `pyproject.toml`, `setup.py` (static parse only; never executed) |
| npm | `package.json`, `package-lock.json`, `yarn.lock`, `pnpm-lock.yaml` |
| Go | `go.mod`, `go.sum`, `vendor/modules.txt` |
| NuGet | `*.csproj`, `packages.config`, `packages.lock.json`, `Directory.Packages.props` |

Parsers use static file parsing only (lock files give hashes; manifests give ranges, which are recorded as `version_range` with the resolved version unknown).

## 3. Phase 2 flow

1. After stage 2, `library-gateway` takes the inventory, normalizes each library to `(ecosystem, name, version, hash)`, and looks it up in `libraries`. If a fresh result exists (within the re-check interval), reuse it.
2. **Lookup** against open source analysis sources: **[PROPOSED]** query one primary source (a software composition analysis service or public package/vulnerability databases such as OSV, deps.dev, the registries themselves) for existence, age, publisher, vulnerabilities and malware advisories. Choice of source(s) is open question 27, spike S8.
3. Classification: `known`, `unknown` (not found, unrecognized version, hash mismatch against the registry, unusual registry or URL), `flagged` (advisory says vulnerable or malicious).
4. `unknown` and `flagged` libraries become **supply-chain POIs** (category G) on every component using them, with `analysis_pending` status. They are never marked clean by default.
5. Unknown libraries are submitted to the **library analysis service** (section 4). The scanner continues without waiting; results arrive asynchronously and update the library record, the POIs, and the profile.
6. Re-check: known-good results are refreshed on a schedule (**[PROPOSED]** every 7 days for the lookups, since advisories change) and whenever a new advisory feed update arrives; a library that turns flagged reopens its POIs (`auto_reopen` history event).
7. Library categories are tracked: public registry packages, internal shared libraries (looked up in the internal registry), vendored copies, and modified copies of well-known libraries (hash differs from the registry for the same name and version).
8. Enterprise view: "which components use library X" query and dashboard page, for rapid tracing of a bad library.

## 4. Interface to the library analysis service (defined here, implemented there)

**[PROPOSED]** Asynchronous, queue or webhook based, with idempotency by `request_key = hash(ecosystem|name|version|hash)`.

Request (`POST /v1/analyses`):
```json
{
  "request_key": "sha256-hex",
  "library": {"ecosystem": "npm", "name": "left-padz", "version": "1.2.3", "hash": "sha512-...", "source_kind": "registry", "source_ref": "https://registry..."},
  "artifact": {"location": "object-store-uri-or-registry-url", "obtained_by": "service | scanner"},
  "context": {"application_id": "...", "component_id": "...", "first_seen_scan": "..."},
  "reasons": ["unknown_to_osint", "unusual_registry"],
  "callback": "https://scanner/internal/library-results"
}
```
Response (immediate): `{"request_key": "...", "status": "accepted | duplicate | rejected", "eta_seconds": 0}`.
Result (callback or `GET /v1/analyses/{request_key}`):
```json
{
  "request_key": "...",
  "status": "complete | failed | inconclusive",
  "verdict": "no_findings | vulnerable | suspicious | malicious | unknown",
  "findings": [{"type": "vulnerability|malicious_behavior|obfuscation|install_script", "title": "...", "severity": "...", "evidence_ref": "uri", "confidence": "..."}],
  "confidence": "high|medium|low",
  "analyzed_at": "ts", "analysis_version": "..."
}
```
Rules: the scanner stores `verdict`, `evidence_ref` and `analyzed_at` on the library, the POIs and the profile. `inconclusive`, `failed` or timeout leave the POI open (`analysis_pending`). The scanner never downloads or executes library code itself; the service obtains the artifact (preferred) or the scanner passes only a location it already validated through `common_fetch`.

## 5. Open items for phase 2 design

1. Which analysis source(s) and their coverage (27).
2. Interface style and service level (28), ownership of the service (28).
3. Treatment of internal shared libraries (scan their source with this scanner as components, linking the library inventory entry to the component).
4. Handling of ranges versus resolved versions when lock files are absent.
5. Retention of library analysis evidence.

## 6. Acceptance criteria (phase 2)

- Inventory completeness on the corpus apps (all declared libraries found, with versions and hashes where available).
- Unknown/mismatched/unusual-source seeds produce POIs; known seeds do not.
- Service outage leaves POIs `analysis_pending`; nothing is marked clean.
- A newly flagged library reopens POIs across all components using it, and the enterprise usage query lists them.
