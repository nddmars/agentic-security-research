# 18 Model Review Module (Separate, Phase 3) and Record Retention

Author: Surya
Status: Design v1.2 (2026-11-12). The model layer (05) is moved out of the scanner into a separate optional module. Decided by Surya in the voice sessions.

## 1. Model review module

- The scanner does its work with no model. Findings found by rules, engine and tree-sitter are reported as they stand.
- The review module is separate, optional, and configurable by an administrator (enable or disable). Built in phase 3, after the scanner is solid (phases 1 and 2).
- It runs after the scan, selects findings by state, and records its output as proposed decisions only, so the workflow (17) still applies and a person finalizes. Output is marked with actor type `agent`.
- Tasks inherited from 05 (T1 to T6): judging business function versus utility, second pass for odd or obfuscated code, route/menu inference for unknown frameworks, enrichment. Which tasks come first: open question.
- Without the module, unknown-framework routes and menus show `unknown` until the module (or a human) fills them in.
- The cost cap and budgets (decision #14) belong to this module as configuration. Scan behavior at cap no longer applies; scans never wait on a model. `intelligence_partial` is replaced by module-level status.
- Guardrails from 05 carry over: additive only, cited snippets, secret masking, approved models via the gateway.

Impact on other files: stage 5 (intelligence) in 00 becomes an optional post-scan module; stage 6 assembly no longer waits for it; T-task design in 05 is reused by the module.

## 2. Retention

- Retention is **not a product feature**. The product keeps everything.
- A separate script archives records older than a configurable number of years (set by records-management policy). It is not integrated into the services.
- Requirements for the script:
  1. Archive before delete, and write a manifest of what moved (counts, ids, hashes).
  2. Skip anything still open (`to_verify`, `proposed_*`), so history is never cut mid-review.
  3. Log every run for audit.
  4. Support excluding specific projects (legal hold).
  5. Source code is already deleted after each scan; artifacts follow the policy configured in the script.
- Open: archive to cheaper restorable storage vs permanent deletion after a set time.
