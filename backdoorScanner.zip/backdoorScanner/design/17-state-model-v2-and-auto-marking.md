# 17 Configurable Workflow, States, Severity, Suppression and Similarity-Based Marking

Author: Surya
Status: Design v1.2 (2026-11-12). Decided by Surya in the 2026-11-12 voice sessions. Replaces the old state set, the allowlist and the "metadata only" cross-project rule.

## 1. Principle: the administrator designs the workflow

Nothing about who may do what is fixed in code. The administration panel (15) defines states, severities, transitions and the roles allowed to perform each transition. This includes whether the person who proposed a decision may also finalize it. The code only enforces whatever the active workflow definition says, and writes history for every change.

## 2. Workflow definition (data, versioned, audited)

```sql
CREATE TABLE wf_states (
  state_key TEXT PRIMARY KEY, label TEXT NOT NULL,
  is_initial BOOLEAN DEFAULT FALSE,        -- exactly one: where new/reopened POIs start
  is_open BOOLEAN DEFAULT TRUE,            -- open states are skipped by the archive script (18)
  kind TEXT,                               -- optional tag: proposed | final | other
  sort_order INT, active BOOLEAN DEFAULT TRUE
);
CREATE TABLE wf_transitions (
  transition_id UUID PRIMARY KEY, from_state TEXT, to_state TEXT,
  allowed_roles TEXT[] NOT NULL,           -- roles that may perform it
  require_comment BOOLEAN DEFAULT TRUE,
  require_different_actor BOOLEAN DEFAULT FALSE,   -- true = actor must differ from whoever moved the POI into from_state (maker-checker)
  require_severity BOOLEAN DEFAULT FALSE,
  active BOOLEAN DEFAULT TRUE
);
CREATE TABLE wf_severities (severity_key TEXT PRIMARY KEY, label TEXT, sort_order INT, is_default_on_confirm BOOLEAN, active BOOLEAN);
CREATE TABLE wf_versions (version INT PRIMARY KEY, definition JSONB, changed_by TEXT, changed_at TIMESTAMPTZ, reason TEXT);  -- every admin change
```

Role definitions and permissions live in the administration panel (15). Each history row stores the workflow version in force.

### Seed workflow (shipped as the default; the administrator may change anything)

| State | Meaning |
|---|---|
| `to_verify` (initial) | New or reopened; nobody has decided |
| `proposed_not_exploitable` | Someone judged it not an issue; awaits a second review |
| `not_exploitable` | Confirmed not an issue |
| `proposed_backdoor` | Someone judged it a backdoor; awaits a second review |
| `confirmed_backdoor` | Confirmed backdoor; severity assigned |

Seed transitions: `to_verify` to either `proposed_*` (analyst role); `proposed_not_exploitable` to `not_exploitable` and `proposed_backdoor` to `confirmed_backdoor` (reviewer/lead role, `require_different_actor = true`, `confirmed_backdoor` has `require_severity = true`); reopen paths back to `to_verify`. The seed roles and the `require_different_actor` flags are only defaults: Surya decided the administrator may change them, including allowing the same person to finalize. "Not Exploitable" keeps its name unless renamed in the panel (labels are data).

## 3. Severity

Separate column on the POI state, not a state. Values come from `wf_severities` (seed: critical, priority, high, medium, low). When a transition with `require_severity` runs (seed: confirming a backdoor), the actor is prompted; the default is `priority` and can be raised to `critical` or set to any active value. A maker may suggest a severity when proposing; the finalizing actor's value is the one stored. Scanner `priority_hint` (09) stays a separate field.

## 4. Suppression by rule ID (replaces the allowlist)

The allowlist is dropped (decided). Instead, the administration panel has **Suppress rule**:
- Scope: global, or selected projects/components.
- Fields: rule ID, scope, reason (mandatory), suppressed_by, created_at, optional expiry.
- Behavior **[PROPOSED, confirmed in voice by Claude, not objected to]**: findings of a suppressed rule are still recorded and shown as `suppressed` (filterable, counted separately, excluded from the review queue and default views), never silently dropped. Lifting a suppression or expiry returns them to the queue in the initial state. Every change is audited.
- Per-finding approval across projects is done by similarity-based marking (section 5), not by an allowlist.

```sql
CREATE TABLE rule_suppressions (
  suppression_id UUID PRIMARY KEY, rule_id TEXT NOT NULL,
  scope TEXT NOT NULL, scope_ids UUID[],            -- global | project | component
  reason TEXT NOT NULL, created_by TEXT NOT NULL, created_at TIMESTAMPTZ NOT NULL,
  expires_at TIMESTAMPTZ, status TEXT NOT NULL      -- active | expired | lifted
);
```
`scan_pois.suppression_id` is set when a suppression applied.

## 5. Similarity-based marking

When a reviewer decision exists on a finding and **identical code** (same `exact_id`, i.e. the same similarity ID) with the **same finding** (same rule/technique) exists in other projects:

1. The decision is applied to those findings **as a proposed state** (the matching `proposed_*` state), pending review by whoever the workflow allows to finalize. Nothing becomes final automatically.
2. Each automatic action is labelled `origin = auto` with source project, finding, reviewer and time; one-click override.
3. **Reachability gate:** copy only when reachability is comparable (not hidden/role-restricted in one project and menu-exposed in the other); otherwise the item appears in the review screen as a suggestion.
4. **Manual override always wins:** a state set by a person is never overwritten by automation.
5. **Near-matches** (fuzzy only) are suggestions, never applied automatically.
6. The system records which projects were affected and how many (`auto_mark_batches`).
7. Administrator switches (panel): marking on/off, which source states are eligible (seed: both proposed states; **open:** whether `proposed_backdoor` should be copied at all, default off for backdoor decisions until confirmed).

### Similarity review screen (MCD-Ops lead)
Lists automatically applied or suggested decisions, grouped by original decision, with affected project count, source reviewer, one-click override, and approve/reject for a whole group.

### Data additions
`poi_state_current`: `severity`, `origin` (`manual|auto|agent`), `auto_source_fingerprint`, `moved_into_state_by`. `poi_state_history`: `workflow_version`, event types `proposed`, `finalized`, `auto_proposed`, `override`, `group_approved`, `group_rejected`, `suppressed`, `unsuppressed`.
```sql
CREATE TABLE auto_mark_batches (batch_id UUID PRIMARY KEY, source_fingerprint BYTEA, source_state TEXT, created_at TIMESTAMPTZ, affected_count INT);
CREATE TABLE auto_mark_items (batch_id UUID, fingerprint BYTEA, project_id UUID, applied_state TEXT, status TEXT);  -- applied | suggested | overridden | approved | rejected
```

## 6. Interaction with scans

Unchanged code keeps its state across scans (07). Changed code or a changed rule `logic_version` returns the POI to the initial state (07 sections 3, 3.1). The scanner and any model module only create initial-state records or proposed states; they never finalize.

## 7. Acceptance criteria

- The workflow definition drives every allowed transition: removing a role from a transition blocks it in API and UI; editing it writes a `wf_versions` row.
- With `require_different_actor = true`, the same user cannot finalize a POI they moved into the proposed state, even holding both roles; with it false, they can.
- A role without permission cannot reach `confirmed_backdoor` via API.
- Suppressing a rule hides its findings from the queue but they remain visible under the `suppressed` filter with reason and actor; lifting restores them.
- Identical code in 10 projects: one decision produces 10 proposed copies for review; none final; a manual change on one survives later automation.
- Near-match produces a suggestion only.
- Severity prompt appears on a transition with `require_severity`, default `priority`.
