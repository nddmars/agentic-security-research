# 08 Platform and Services

Author: Surya
Status: Design v1. Hosting follows cxtriage unless decided otherwise (open question 29/30). All technology choices are **[PROPOSED]**.

## 1. Service map

| Service | Responsibility | Scales on |
|---|---|---|
| `intake-api` | Receives build triggers (webhook), validates, creates scans, exposes status | Request rate |
| `acquire-worker` | Stage 1: fetch, safe-extract, inventory | Queue depth; ephemeral volume size |
| `profile-worker` | Stage 2: profile, classification, fingerprint reuse | Queue depth |
| `detect-worker` | Stage 3: parse, rules, call graph. Classes: `std` and `heavy` (large repos) | Queue depth, repo size |
| `reach-worker` | Stage 4: adapters, linking | Queue depth |
| `intel-worker` | Stage 5: model calls via gateway | Queue depth, gateway rate limits |
| `assemble-worker` | Stage 6: merge, IDs, state carry-over, diff, report | Queue depth |
| `similarity-service` | Function IDs matching, component similarity, API (06) | Request rate, index size |
| `cmdb-sync` | Scheduled CMDB import and difference flags | Schedule |
| `commit-resolver` | Async build ID to commit | Queue depth |
| `lifecycle-manager` | Inactive/retired transitions, reactivation scans | Schedule |
| `poi-api` | Read/write API for POIs, state, workflow, suppression, reports (09) | Request rate |
| `dashboard` | Web UI | Users |
| `library-gateway` (phase 2) | Calls the library analysis service (11) | Queue depth |

## 2. Orchestration and queue

Requirement: durable queue, replicas, resume at the failed stage. **Decided:** use **Temporal** for scan workflows (the same recommendation as cxtriage, so one platform skill set), with one workflow per scan and one activity per stage. Activities are idempotent, take their input from object storage references, and write outputs under `scan_id/stage/attempt` keys. Retries with backoff; per-activity timeouts sized by repository tier.

Fallback if Temporal is not approved: a durable broker (RabbitMQ or Kafka) plus a `scan_stage_runs` state table and an orchestrator service; the contract (stage inputs and outputs as artifacts, completion events, idempotency) stays identical. Decision at S6.

Workflow shape per scan: `acquire -> profile -> detect -> (reach, similarity-notify in parallel) -> intel -> assemble`, with `commit-resolver` started as a child, non-blocking. Stage 5 can be skipped by configuration or by budget exhaustion.

## 3. Storage

| Data | Store |
|---|---|
| Entities, POIs, state, history, lifecycle, CMDB records | PostgreSQL (primary + replicas, managed or operator-based) |
| Extracted source (ephemeral) | Pod ephemeral volume, deleted after stage 6 (or at failure TTL) |
| Artifacts (inventory, candidates, call graph, reports, profiles) | S3-compatible object storage, versioned keys, lifecycle rules |
| Similarity index | Postgres tables first; dedicated engine if needed (06 section 7) |
| Cache (model results by snippet hash, fetch dedupe) | Postgres or Redis **[PROPOSED]** Redis for short-lived cache |
| Audit | Append-only tables plus shipped logs |

## 4. High availability

- Every service runs 2 or more replicas across failure domains; workers are stateless.
- Postgres with synchronous replica and automated failover; point-in-time recovery.
- Temporal cluster with persistence on the HA Postgres (or managed offering).
- Stage idempotency means a killed pod causes a retry, not a restart of the scan.
- Back-pressure: queue depth alarms and a global concurrency limit per worker class to protect the gateway and the database.

## 5. Capacity guide

- Average 8 scans/hour, **[PROPOSED]** design peak 40/hour, plus catch-up of 200 queued after an outage.
- `detect-worker` is the heavy consumer. Starting point: `std` workers of 4 vCPU / 8 GB, `heavy` workers of 8 vCPU / 32 GB for repositories above a size tier; both configurable. Measure in S1 and adjust.
- `intel-worker` is bound by model rate limits and budget, not CPU.
- Postgres sizing from rows per scan: files (tens of thousands), functions (up to millions for the largest repos), POIs (hundreds to thousands). Partition `scan_files`, `scan_functions` and `scan_pois` by scan month; archive old partitions to object storage after the retention period.

## 6. Hosting **[PROPOSED]**

OpenShift as in cxtriage: `restricted-v2` SCC, random non-root UID, GID 0 group-writable scratch paths, NetworkPolicy default-deny, EgressFirewall allowing only the artifact host(s), the model gateway, the pipeline API, CMDB and the results store; Routes with SSO for the API/dashboard. Reuse the cxtriage infrastructure file `13-infrastructure.md` conventions and templates. Whether to share the cluster and namespaces with cxtriage (open question 30): **[PROPOSED]** same cluster, separate namespaces and worker classes, shared platform services (Temporal, Postgres operator, observability).

## 7. Observability

Prometheus-style metrics: scans by status, stage latency/failure, queue depth, parse failure rate by language, coverage percentage, rules fired per category, POIs per scan, model tokens/cost, budget exhaustion count, similarity lag, CMDB difference counts, commit resolution rate. Structured logs with `scan_id` correlation; traces across stages. Alerts: stuck scans, repeated fetch failures per component, parse failure spikes (a rule or grammar regression), gateway errors.

## 8. API surface between services

Services talk through the workflow (artifact references) and a few HTTP APIs: `similarity-service` (06), `poi-api` (09), `intake-api`. All internal calls use mTLS or the platform service mesh, with service accounts and least privilege (workers cannot read other scans' artifacts: prefix-scoped credentials per scan).

## 9. Security of the platform

Per cxtriage `12-security-isolation.md` and this project's requirement 07: baseline controls always on (non-root, read-only root filesystem, resource limits, default-deny network, secrets in a secret manager, no source in logs, masked evidence), optional hardening where policy allows (separate namespaces and node pools for `acquire`/`detect` workers, gVisor-like sandboxes). "Hostile" here means not assumed safe, including internal code.

## 10. Acceptance criteria

- Kill a worker pod at each stage: the scan completes with no duplicate or missing output.
- 40 scans per hour sustained with the target repository mix, queue drains within the agreed time.
- Database failover during load does not lose acknowledged results.
- Default-deny network verified: analysis pods cannot reach anything except their allowlist.
