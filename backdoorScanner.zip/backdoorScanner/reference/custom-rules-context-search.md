# Custom Rules Context Search (Triage Agent Addition)

Author: Surya
Date: 2026-11-02
Status: Design addition for the Checkmarx triage agent (cxtriage). Copied here as a reference because the same context-gathering approach is reused by the scanner's intelligence layer (`../design/05-intelligence-layer.md`). Still to be merged into the cxtriage pack (files 00, 03, 07, 15 and 16).

## Problem

Checkmarx out-of-the-box rules produce **path-based** findings: a source, a sink, the data flow between them, and the file names and lines on that path. The agent can gather the files on the path and send them to the model.

Checkmarx **custom pattern rules** (for example hardcoded username, hardcoded IP address) produce **pattern-only** findings: a file, a line and the matched text. There is no source, sink or flow. So there is nothing that tells us which other files are related. We must infer the related context from the one location we have, then send it to the model.

## Approach: fixed recipe plus a few model lookups

1. **Fixed recipe first.** Each pattern rule has a recipe: a fixed, deterministic list of context-gathering steps. Same steps every time, every snippet logged and cited.
2. **A few model-requested lookups.** If the model says the context is not enough, it may ask for a small number of extra lookups (for example one more search for a name). Lookups are limited in count, logged, and run by our code, never by the model directly.
3. **Learning loop (training phase).** Model-requested lookups are logged per rule and language. When the same lookup keeps being requested, it is proposed for promotion into that rule's fixed recipe. Over time the recipes absorb what the model keeps asking for, and the model needs fewer lookups in production. Promotion needs human approval, and each promoted step must be checked against the golden set to show it improves accuracy and does not only add noise or cost.

## Generalizing: match types

Instead of one hand-written recipe per rule, classify each pattern rule by what it matches. The type chooses the recipe.

- **Hardcoded value** (password, key, token, IP address, username): enclosing function, then where the value or its constant is used, then callers, plus nearby config and test paths.
- **Dangerous call** (weak crypto, risky API): enclosing function, arguments, and how the call result is used.
- **Risky configuration setting**: the config file, where the setting is read, and environment overrides.
- **Missing safeguard** (no input check, no auth check): enclosing function, its callers, and any shared filter or middleware.

Each rule is tagged with its match type and language. New rules only need a tag, not a new recipe.

## Building blocks (the context steps)

All recipes are made from the same few steps:

1. Enclosing function or class around the matched line, plus the file's imports and constants.
2. Where the matched value or the name that holds it is used (references).
3. Callers of the enclosing function.
4. Neighbors by convention: config and properties files, environment files, test and fixture directories, same package.
5. Package the results as cited snippets within a size budget.

## Libraries (simplest approach)

The simplest approach uses two tools and nothing else:

- **ripgrep** for text search across the repository. It searches directories recursively on its own, so one call covers the repo. Called as a command-line tool from the service.
- **tree-sitter** (Python bindings) to parse a file and pull out the enclosing function or class and in-file definitions and references. Grammars exist for Java, Python, JavaScript and TypeScript, Go and C#. It works per file and uses little memory.

Flow: ripgrep finds where the matched value or symbol appears, tree-sitter extracts the enclosing function for each hit, the hits are collected, capped at a size budget, and sent to the model as cited snippets.

### Hops, not open recursion

One search per hop, with a fixed small number of hops. For a hardcoded value: search for the value, then if it sits in a constant, search for where the constant is used, then at most one more level to callers. Cap at two hops, because each extra hop multiplies noise and context size.

### Optional later

- A ranking step in the style of Aider's repo map (files as graph nodes, symbol references as edges, PageRank, token-budget fitting). Open source ports such as RepoMapper exist. Add only if context becomes too large or too noisy.
- Language servers (LSP) for more accurate references and callers per language. Heavy at this scale because each language needs a server and a project that resolves cleanly. Not for the first release.

## Why not Joern for pattern findings

Joern builds a code property graph for the whole repository, which is memory-expensive on large repositories (up to 12 GB here) and slow to build, even when only one symbol matters. At about 80,000 findings a week that cost matters.

Proposed split:
- **Path-based findings:** keep Joern, because they need real flow facts. Build the graph once per scan and reuse it for every finding in that scan, with a repository size cap and a cheaper fallback above it.
- **Pattern-only findings:** use ripgrep plus tree-sitter.

This changes the earlier cxtriage decision that tree-sitter is phase 2 only. Under this proposal tree-sitter is used in phase 1 for pattern-only findings. The cxtriage pack must be updated accordingly when this is merged (files 00, 03, 15 and 16).

## Precision and safety rules

- Context from this process is **name-based** precision, not proven flow. Tag every snippet and the pack as inferred.
- A false-positive verdict resting on name-based context gets extra scrutiny. Under the asymmetry rule, absence of references found by search is not proof of absence.
- Snippets are cited by ID, secrets are masked before anything reaches the model, and code is treated as data, never instructions.
- Test and fixture paths are strong evidence that a hardcoded value is harmless, but they are a hint, not a fact, and the validator still applies.
- Never silently drop a hit: if the size budget cuts context, record what was cut.

## Open questions

1. Exact list of pattern rules in use and their match types.
2. Size budget per finding for context (tokens and number of snippets).
3. Maximum number of model-requested lookups per finding.
4. Who approves recipe promotions from the learning loop, and how often.
5. Threshold for how often a lookup must be requested before it is proposed for promotion.
6. Whether to adopt a repo-map style ranking step, decided after measuring context size on real findings.
7. Repository size cap for Joern, and what the fallback path does above it.
