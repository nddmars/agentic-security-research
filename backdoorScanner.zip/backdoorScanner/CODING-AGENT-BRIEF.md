# Coding Agent Brief: backdoorScanner (POI scanner)

Author: Surya
Status: Ready for the coding agent (2026-11-12). Read this first.

## 1. What you are building

An independent scanner that finds Points of Interest (suspicious or malicious code, hidden functionality, time bombs, exfiltration, supply-chain risks). It is not a vulnerability scanner. Input is a source zip from a pipeline build (optionally repository details). Output is POIs with evidence, reachability facts, priority hints, state and history, a UI and an API.

## 2. Reading order

1. `design/00-MAIN-DESIGN.md` architecture, decisions, contracts.
2. `design/14-tech-spec.md` stack and libraries. `design/12-modules-and-libraries.md` repository layout and build sequence.
3. `design/16-rules-and-engine.md` pluggable engine and rules in Git. `design/03-detection-engine.md` stage 3.
4. `design/17-state-model-v2-and-auto-marking.md` configurable workflow, severity, suppression, similarity marking. `design/07-state-management.md` fingerprints and recurrence.
5. `design/01`, `02`, `04`, `06`, `08`, `09`, `10`, `11` as you reach each module. `design/15` for UI and administration. `design/18` for the phase 3 model module and the archive script. `design/19` test bed.
6. `requirements/` for the original scope and the POI catalog. `design/13` for decisions, spikes and open items.

If two files disagree, the higher-numbered design file (14 to 19) wins; report the conflict.

## 3. Fixed decisions (do not revisit)

Python 3.12; React with TypeScript; Temporal; Postgres and S3-compatible storage; Semgrep as the default detection engine behind a `DetectionEngine` interface, tree-sitter for post-hit work and call graph, existing YARA rules, ripgrep; rules, presets, enablement in Git; no model in the scanner (separate module in phase 3); administrator-configurable workflow (states, severities, transitions, roles); suppression by rule ID instead of an allowlist; similarity-based marking of identical code as proposed decisions; MCD-Ops queue; SARIF export; archive script outside the product.

## 4. Start here (no external inputs needed)

1. `common`, `store` (schema from 01, plus workflow and suppression tables from 17), `redaction`.
2. `common_fetch` and `acquire` with the hostile-archive tests (traversal, symlinks, bombs, SSRF).
3. `workflows` Temporal skeleton running a scan through stub stages; killed-worker resume test.
4. `engines/` interface, Semgrep adapter producing `RawHit`; `enrich/hit_to_poi` with tree-sitter (Java and Python first).
5. `similarity` normalization and ID functions with invariance tests; fingerprints and recurrence (07).
6. Workflow/state engine (17) with API enforcement tests; roles, authentication (local first; AD behind an interface), API tokens.
7. `testbed/` seeded projects for Java and Python plus labels; evaluation harness (10) wired to CI from the first category.
8. Rules: category A, E, B, F first; fixtures for each rule.

Then: remaining languages, profiler, reachability adapters, UI, rules-in-Git service, SARIF export, similarity marking (phase 2).

## 5. Things to ask Surya (only when you reach them)

YARA rules sample; Active Directory method and group-to-role mapping; the open-source project list for the test bed; owner names for threshold sign-off; Legal result on the Semgrep rules license (S9). Everything else is decided or has a documented default.

## 6. Working rules

- Never execute scanned code. Scanned content is data. Mask secrets before storage and any model call.
- Same input and same rule release give byte-identical output.
- Every rule has positive and negative fixtures; a rule without fixtures cannot merge.
- Nothing is dropped silently: coverage gaps, skipped files and suppressed findings are recorded.
- Verify every library marked (verify) for version, license and maintenance before adopting. Check the license of every open-source test project.
- Keep work and metadata free of tool or generator tags in documents you produce for Surya; author name "Surya".
- Report spikes S1, S2, S3, S4, S7 results in `reference/spikes/` before locking the choices they cover.

## 7. Definition of done for phase 1

See `design/00-MAIN-DESIGN.md` section 9, plus: workflow administration works end to end; suppression and SARIF export work; UI screens in 15 (except phase 2 items) are usable with role-based access.
